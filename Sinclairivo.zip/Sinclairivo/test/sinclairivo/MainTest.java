/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sinclairivo;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import javax.swing.*;
import java.awt.*;


/**
 * Tests the CPUparser and all the related functions of the ZX Spectrum emulator.
 * @author Mgr. Jan Kapoun
 */
public class MainTest 
{
    
    MainWnd spectrumWindow; 
    ZXMachine spectrum; 
        
    
    public MainTest() 
    {
        spectrumWindow = new MainWnd("Sinclair ZX Spectrum");
        spectrum = new ZXMachine(spectrumWindow);
    }

    @BeforeClass
    public static void setUpClass() throws Exception 
    {
    }

    @AfterClass
    public static void tearDownClass() throws Exception 
    {
    }

    @Before
    public void setUp() 
    {
    }

    @After
    public void tearDown() 
    {
        
    }

    /**
     * Test of Main method, of class spectrum.
     */
    @Test
    public void testMain()
    {
       
    }
    
    
    @Test
    public void testInstructions()
    {
        spectrum.ResetMachine();
    }

   
    @Test
    public void testJUMPS()
    {
        this.Init("JUMPS");
        spectrum.LaunchMachineCode(4, 40000);
        assertEquals(spectrum.regs.regB.Get(), 25);
    }
   
    
    @Test
    public void testLDDR()
    {
        this.Init("lddr");
        spectrum.LaunchMachineCode(14, 40000);
        assertEquals(spectrum.ram.ReadRAM(64010),0);
        assertEquals(spectrum.ram.ReadRAM(64011),34);
        assertEquals(spectrum.ram.ReadRAM(64021),0);
     }
   
   
    @Test
    public void testJR()
    {
        this.Init("JR");
        spectrum.LaunchMachineCode(14, 40000);
        assertEquals(spectrum.regs.regA.Get(), 0);
        assertEquals(spectrum.flg.GetZero(), true );
        assertEquals(spectrum.flg.GetCarry(), false );
    }
   
    
    @Test
    public void testBIT_IX()
    {
        this.Init("BIT_IX");
        spectrum.LaunchMachineCode(4, 40000);
        assertEquals(spectrum.flg.GetZero(), false );
        spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.flg.GetZero(), false );
     }
    
   
     @Test
    public void testCPDR()
    {
        this.Init("CPDR");
        spectrum.LaunchMachineCode(26, 40000);
        assertEquals(spectrum.regs.regHL.Get(), 50004);
        assertEquals(spectrum.regs.regBC.Get(), 4);
        assertEquals(spectrum.flg.GetZero(), true );
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetPV(), true );
     }
    
    @Test
    public void testCPIR()
    {
        this.Init("CPIR");
        spectrum.LaunchMachineCode(26, 40000);
        assertEquals(spectrum.regs.regHL.Get(), 50006);
        assertEquals(spectrum.regs.regBC.Get(), 4);
//        assertEquals(spectrum.flg.GetCarry(), true );
        assertEquals(spectrum.flg.GetZero(), true );
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetPV(), true );
     }
    
    @Test
    public void testRLD()
    {
        this.Init("RLD");
        spectrum.LaunchMachineCode(26, 40000);
        assertEquals(spectrum.regs.regA.Get(), 240);
//        assertEquals(spectrum.flg.GetCarry(), true );
//        assertEquals(spectrum.flg.GetZero(), false );
//        assertEquals(spectrum.flg.GetSign(), false );
    }
    
    @Test
    public void testRR()
    {
        this.Init("RR");
        spectrum.LaunchMachineCode(26, 40000);
        assertEquals(spectrum.regs.regA.Get(), 2);
        assertEquals(spectrum.flg.GetCarry(), true );
        assertEquals(spectrum.flg.GetZero(), false );
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetPV(), false );
     }
    
     @Test
    public void testSLA()
    {
        this.Init("SLA");
        spectrum.LaunchMachineCode(26, 40000);
        assertEquals(spectrum.regs.regA.Get(), 0);
        assertEquals(spectrum.flg.GetCarry(), true );
        assertEquals(spectrum.flg.GetZero(), true    );
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetPV(), true );
     }

    
    @Test
    public void testSLL()
    {
        this.Init("SLL");
        spectrum.LaunchMachineCode(6, 40000);
        assertEquals(spectrum.regs.regA.Get(), 1);
        assertEquals(spectrum.flg.GetCarry(), true );
        assertEquals(spectrum.flg.GetSign(), false );
     }
    
    @Test
    public void testPUSH_PC()
    {
        this.Init("PUSH_PC");
        spectrum.LaunchMachineCode(3, 40000);
        assertEquals(spectrum.regs.regPC.Get(), 40000);
    }
    
    @Test
    public void testPUSH_AF()
    {
        this.Init("pushAF");
        spectrum.LaunchMachineCode(30, 40000);
        assertEquals(spectrum.regs.regH.Get(), 0);
    }
    
    
    @Test
    public void testCALL()
    {
        this.Init("CALL");
        spectrum.LaunchMachineCode(200000, 40000);
        assertEquals(spectrum.regs.regA.Get(), 10);
        assertEquals(spectrum.regs.regBC.Get(), 34000);
        assertEquals(spectrum.regs.regDE.Get(), 23000);
        assertEquals(spectrum.regs.regHL.Get(), 25000);
    }
    
    @Test
    public void testRET()
    {
        this.Init("RET");
        spectrum.LaunchMachineCode(200000, 40000);
        assertEquals(spectrum.regs.regB.Get(), 5);
        
    }
    
    
     @Test
    public void testRL_INDEX()
    {
        this.Init("RL_INDEX");
        spectrum.LaunchMachineCode(10, 40000);
//        assertEquals(spectrum.regs.regA.Get(), 239);
//        assertEquals(spectrum.flg.GetCarry(), true );
    }
   
     @Test
    public void testRRC()
    {
        this.Init("RRC");
        spectrum.LaunchMachineCode(10, 40000);
        assertEquals(spectrum.regs.regA.Get(), 12);
        assertEquals(spectrum.flg.GetCarry(), false );
        assertEquals(spectrum.flg.GetZero(), false );
        assertEquals(spectrum.flg.GetPV(), true );
    }
   
    
     @Test
    public void testRL()
    {
        this.Init("RL");
        spectrum.LaunchMachineCode(10, 40000);
        assertEquals(spectrum.regs.regA.Get(), 239);
        assertEquals(spectrum.flg.GetCarry(), true );
        assertEquals(spectrum.flg.GetSign(), true );
        assertEquals(spectrum.flg.GetPV(), false );
        assertEquals(spectrum.flg.GetZero(), false );
     }
     
    @Test
    public void testSRL()
    {
        this.Init("SRL");
        spectrum.LaunchMachineCode(6, 40000);
        assertEquals(spectrum.regs.regA.Get(), 0);
        assertEquals(spectrum.flg.GetCarry(), true );
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetPV(), true );
        assertEquals(spectrum.flg.GetZero(), true );
        
        spectrum.LaunchMachineCode(6);
        assertEquals(spectrum.regs.regA.Get(), 0);
        assertEquals(spectrum.flg.GetCarry(), false );
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetPV(), true );
        assertEquals(spectrum.flg.GetZero(), true );
        
        
        spectrum.LaunchMachineCode(6);
        assertEquals(spectrum.regs.regA.Get(), 252);
        assertEquals(spectrum.flg.GetCarry(), false );
        assertEquals(spectrum.flg.GetSign(), true );
        assertEquals(spectrum.flg.GetPV(), true );
        assertEquals(spectrum.flg.GetZero(), false );
        
        spectrum.LaunchMachineCode(6);
        assertEquals(spectrum.regs.regA.Get(), 0);
        assertEquals(spectrum.flg.GetCarry(), false );
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetPV(), true );
        assertEquals(spectrum.flg.GetZero(), true );
        
        
        
    }
    
    @Test
    public void testRLC()
    {
        this.Init("RLC");
        spectrum.LaunchMachineCode(40, 40000);
        
        assertEquals(spectrum.regs.regB.Get(), 1);
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetCarry(), true );
        
    }
    
    @Test
    public void testRLCA()
    {
        this.Init("RLCA");
        spectrum.LaunchMachineCode(40, 40000);

            //ld a, 31
            //rlca
            //rlca
            //rlca
            //rlca
            //ld b,a
            //ld a,1
            //rlca
            //rlca
            //rlca
            //rlca
            //ld c,a
            //ld a,255
            //rlca
            //rlca
            //rlca
            //rlca        
        
        
        assertEquals(spectrum.regs.regB.Get(), 241);
        assertEquals(spectrum.regs.regC.Get(), 16);
        assertEquals(spectrum.regs.regA.Get(), 255);
        assertEquals(spectrum.flg.GetCarry(), true);
        
        System.out.println("testRLCA done...");
    }
   
    
    @Test
    public void testLDIR_LDDR()
    {
        this.Init("LDIR_LDDR");
        spectrum.LaunchMachineCode(80, 40000);
        
        for (int i = 0; i < 15; i++)
        {
            System.out.println(spectrum.ram.ReadRAM(000 + i));
        
        }
        //assertEquals(spectrum.ram.ReadRAM(64000), 243);
        //assertEquals(spectrum.ram.ReadRAM(64019), 255);
        //assertEquals(spectrum.ram.ReadRAM(64020), 0);
    }
    
    @Test
    public void testBIT()
    {
        this.Init("BIT");
        spectrum.LaunchMachineCode(180, 40000);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), true);
//        assertEquals(spectrum.flg.GetSign(), false);
//        assertEquals(spectrum.flg.GetPV(), false);
        
        assertEquals(spectrum.regs.regC.Get(), 0);
        assertEquals(spectrum.regs.regB.Get(), 255);
        assertEquals(spectrum.regs.regD.Get(), 128);
        assertEquals(spectrum.regs.regE.Get(), 128);
        assertEquals(spectrum.regs.regL.Get(), 128);
    }
    
    @Test
    public void testADD2()
    {
        this.Init("ADD2");
        spectrum.LaunchMachineCode(20, 40000);
        
        
        assertEquals(spectrum.regs.regHL.Get(), 128);
        System.out.println("HL: "+ spectrum.regs.regHL.Get() );
     }
    
    @Test 
    public void testADD()
    {
       spectrum.ram.ResetRAM();
       RAMLoadSaveFile fl = new RAMLoadSaveFile("C:\\Documents and Settings\\Administrator\\JAVA\\ZXSpectrum emulator\\ZX Spectrum\\ADD.bin", spectrum.ram, 40000);
       fl.Load();
       spectrum.LaunchMachineCode(40, 40000);
       
            //ld hl,40000
            //ld sp,30000
            //or a
            //add hl,sp   
            //add hl,hl
            //add hl,hl
            //add hl,hl
            //add hl,hl
       
            //ld ix,50000
            //ld bc,20000
            //or a
            //add ix,bc
            //ld iy,50000
            //or a
            //add iy,bc       
       
       
       assertEquals(spectrum.regs.regHL.Get(), 5888);
       assertEquals(spectrum.flg.GetCarry(), true);
       assertEquals(spectrum.regs.regIX.Get(), 4464);
       assertEquals(spectrum.regs.regIY.Get(), 4464);
       
       System.out.println("testADD done...");
     
    }
    
    
   // @Test
    public void testADC()
    {
       spectrum.ram.ResetRAM();
       RAMLoadSaveFile fl = new RAMLoadSaveFile("C:\\Documents and Settings\\Administrator\\JAVA\\ZXSpectrum emulator\\ZX Spectrum\\ADC.bin", spectrum.ram, 40000);
       fl.Load();
       spectrum.LaunchMachineCode(40, 40000);
       
            //ld hl,50000
            //ld sp,20000
            //scf
            //adc hl,sp
            //ld de,10000
            //adc hl,de
            //ld bc,10000
            //adc hl,bc   
       
       assertEquals(spectrum.regs.regHL.Get(), 24466);
       assertEquals(spectrum.flg.GetCarry(), false);
       
       System.out.println("testADC done...");
        
    }
   
    @Test 
    public void testSBC_REG8()
    {
       spectrum.ram.ResetRAM();
       RAMLoadSaveFile fl = new RAMLoadSaveFile("C:\\Documents and Settings\\Administrator\\JAVA\\ZXSpectrum emulator\\ZX Spectrum\\SBC_REG8.bin", spectrum.ram, 40000);
       fl.Load();
       spectrum.LaunchMachineCode(40, 40000);

            //ld hl,50000
            //ld (hl),34
            //ld a,34
            //scf
            //sbc a,(hl)
            //ld b,a
            //ld ix,60000
            //ld (ix + 12),54
            //ld a,54
            //sbc a,(ix + 12)       
       
       assertEquals(spectrum.regs.regA.Get(), 255);
       assertEquals(spectrum.regs.regB.Get(), 255);
       assertEquals(spectrum.flg.GetCarry(), true);
        
       System.out.println("testSBC_REG8 done...");
       
    }
    
    @Test 
    public void testSBC()
    {
       spectrum.ram.ResetRAM();
       RAMLoadSaveFile fl = new RAMLoadSaveFile("C:\\Documents and Settings\\Administrator\\JAVA\\ZXSpectrum emulator\\ZX Spectrum\\SBC.bin", spectrum.ram, 40000);
       fl.Load();
       spectrum.LaunchMachineCode(40, 40000);
       
            //ld hl,30000
            //scf
            //sbc hl,hl
            //sbc hl,hl
            //sbc hl,hl
       
       System.out.println("reg HL: " + spectrum.regs.regHL.Get());
       assertEquals(spectrum.regs.regHL.Get(), 65535);
       assertEquals(spectrum.flg.GetCarry(), true);
        
       System.out.println("testSBC done...");
       
    }
  
    
    @Test
    public void testINC_IX()
    {
        this.Init("DEC_IY");
        
            
        spectrum.LaunchMachineCode(20, 40000);
        assertEquals(spectrum.regs.regA.Get(), 44);
        
    }
   
  //  @Test
    public void testAND_OR_XOR()
    {
        this.Init("AND_OR_XOR");
        
            //ld a,255
            //and 0
            
        spectrum.LaunchMachineCode(2, 40000);
        assertEquals(spectrum.regs.regA.Get(), 0);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), true);
        assertEquals(spectrum.flg.GetSign(), false);
        assertEquals(spectrum.flg.GetPV(), true);
        
        
            //ld a,255
            //and 200

        spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.regs.regA.Get(), 200);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), false);
        assertEquals(spectrum.flg.GetSign(), true);
        assertEquals(spectrum.flg.GetPV(), false);
        
            //ld a,20
            //and 255

        spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.regs.regA.Get(), 20);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), false);
        assertEquals(spectrum.flg.GetSign(), false);
        assertEquals(spectrum.flg.GetPV(), true);
        
        
            //ld a,255
            //or 200

        spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.regs.regA.Get(), 255);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), false);
        assertEquals(spectrum.flg.GetSign(), true);
        assertEquals(spectrum.flg.GetPV(), true);
        
        
            //ld a,200
            //or 0

        spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.regs.regA.Get(), 200);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), false);
        assertEquals(spectrum.flg.GetSign(), true);
        assertEquals(spectrum.flg.GetPV(), false);
        
//            ld a,200
//            or 200
        
        spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.regs.regA.Get(), 200);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), false);
        assertEquals(spectrum.flg.GetSign(), true);
        assertEquals(spectrum.flg.GetPV(), false);
        
            //ld a,200
            //xor 255
        
        spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.regs.regA.Get(), 55);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), false);
        assertEquals(spectrum.flg.GetSign(), false);
        assertEquals(spectrum.flg.GetPV(), false);
        
      
            //ld a,255
            //xor 5
        
         spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.regs.regA.Get(), 250);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), false);
        assertEquals(spectrum.flg.GetSign(), true);
        assertEquals(spectrum.flg.GetPV(), true);
        
        
            //ld a,10
            //xor 10
        
         spectrum.LaunchMachineCode(2);
        assertEquals(spectrum.regs.regA.Get(), 0);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), true);
        assertEquals(spectrum.flg.GetSign(), false);
        assertEquals(spectrum.flg.GetPV(), true);
    }
    
    @Test
    public void testCP()
    {
        this.Init("CP");
        
            //ld a,255
            //cp 1
            
        spectrum.LaunchMachineCode(2, 40000);
   //     assertEquals(spectrum.regs.regHL.Get(), 65535);
        assertEquals(spectrum.flg.GetCarry(), false);
        assertEquals(spectrum.flg.GetZero(), false);
        assertEquals(spectrum.flg.GetSign(), true);
        assertEquals(spectrum.flg.GetPV(), false);
        
        //cp 255
            
         spectrum.LaunchMachineCode(1);
         assertEquals(spectrum.flg.GetCarry(), false);
         assertEquals(spectrum.flg.GetZero(), true);
         assertEquals(spectrum.flg.GetSign(), false);
         assertEquals(spectrum.flg.GetPV(), false);
        
         
            //ld hl,50000
            //ld (hl),244
            //ld a,244
            //cp (hl)
            
         spectrum.LaunchMachineCode(4);
         assertEquals(spectrum.flg.GetCarry(), false);
         assertEquals(spectrum.flg.GetZero(), true);
         assertEquals(spectrum.flg.GetSign(), false);
         assertEquals(spectrum.flg.GetPV(), false);
        
            //ld a,230
            //cp (hl)
            
         
         spectrum.LaunchMachineCode(2);
         assertEquals(spectrum.flg.GetCarry(), true);
         assertEquals(spectrum.flg.GetZero(), false);
         assertEquals(spectrum.flg.GetSign(), true);
         assertEquals(spectrum.flg.GetPV(), false);
        
             //ld (hl),20
            //ld a,250
            //cp (hl)
         
         spectrum.LaunchMachineCode(3);
         assertEquals(spectrum.flg.GetCarry(), false);
         assertEquals(spectrum.flg.GetZero(), false);
         assertEquals(spectrum.flg.GetSign(), true);
         assertEquals(spectrum.flg.GetPV(), false);
        
    }
    
    @Test
    public void testROM_Sinclair()
    {
        String s;
        for(int i = 0; i<20; i++)
        {
//             = spectrum.ram.ReadRAM(5432 + i);
//            System.out.println(s.);
        }
    }
    
    @Test
    public void testINC_DEC8()
    {
        this.Init("INC_DEC8");
        spectrum.LaunchMachineCode(6, 40000);
        assertEquals(spectrum.regs.regB.Get(), 0);
        assertEquals(spectrum.flg.GetCarry(), false);
         assertEquals(spectrum.flg.GetZero(), true);
         spectrum.LaunchMachineCode(1);
         assertEquals(spectrum.flg.GetZero(), false);
         spectrum.LaunchMachineCode(1);
         assertEquals(spectrum.flg.GetZero(), true);
    }
    
        
    
    @Test
    public void testINC_DEC16()
    {
        this.Init("INC_DEC16");
        spectrum.LaunchMachineCode(40, 40000);
        
        
            // ld bc,65535
            //ld a,1
            //or a
            //
            //inc bc
            //inc bc
            //
            //ld de,65535
            //inc de
            //inc de
            //
            //ld hl,65535
            //inc hl
            //inc hl
            //
            //ld sp,65535
            //inc sp
            //inc sp
            //
            //ld ix,65535
            //inc ix
            //inc ix
            //
            //ld iy,65535
            //inc iy
            //inc iy
            //
            //dec bc
            //dec de
            //dec hl
            //dec sp
            //dec ix
            //dec iy

        
        assertEquals(spectrum.regs.regBC.Get(), 0);
        assertEquals(spectrum.regs.regDE.Get(), 0);
        assertEquals(spectrum.regs.regHL.Get(), 0);
        assertEquals(spectrum.regs.regIX.Get(), 0);
        assertEquals(spectrum.regs.regIY.Get(), 0);
        
        assertEquals(spectrum.flg.GetSign(), false );
        assertEquals(spectrum.flg.GetCarry(), false );
        assertEquals(spectrum.flg.GetZero(), false );
        
    }
    
    
    @Test
    public void testEXX()
    {
       spectrum.ram.ResetRAM();
       RAMLoadSaveFile fl = new RAMLoadSaveFile("C:\\Documents and Settings\\Administrator\\JAVA\\ZXSpectrum emulator\\ZX Spectrum\\EXX.bin", spectrum.ram, 40000);
       fl.Load();
       spectrum.LaunchMachineCode(40, 40000);
       
            //ld hl,50000
            //ld de,30000
            //ld sp,60000
            //ld bc,65403
            //push bc
            //
            //ex (sp),hl
            //ex de,hl
            //
            //ld ix,65403
            //ex (sp),ix
            //ld iy,20000
            //ex (sp),iy         
       
        assertEquals(spectrum.regs.regDE.Get(), 65403);
        assertEquals(spectrum.regs.regHL.Get(), 30000);
        assertEquals(spectrum.regs.regIX.Get(), 50000);
        assertEquals(spectrum.regs.regIY.Get(), 65403);
        
        System.out.println("testEXX done...");
    
    }
    
    @Test
    public void testEXX2()
    {
       spectrum.ram.ResetRAM();
       RAMLoadSaveFile fl = new RAMLoadSaveFile("C:\\Documents and Settings\\Administrator\\JAVA\\ZXSpectrum emulator\\ZX Spectrum\\EXX2.bin", spectrum.ram, 40000);
       fl.Load();
       spectrum.LaunchMachineCode(50, 40000);
       
       
            //ld hl,50000
            //ld de,30000
            //ld bc,65403
            //exx
            //ld hl,1
            //ld de,2
            //ld bc,3
       
            //ex de,hl
            //
            //ld a,23
            //scf
            //
            //ex af,af'
            //ld a,1
            //or a
            //ex af,af'
       
       
       assertEquals(spectrum.regs.regDE_.Get(), 30000);
       assertEquals(spectrum.regs.regHL_.Get(), 50000);
       assertEquals(spectrum.regs.regBC_.Get(), 65403);
       assertEquals(spectrum.regs.regHL.Get(), 2);
       assertEquals(spectrum.regs.regDE.Get(), 1);
       assertEquals(spectrum.regs.regBC.Get(), 3);
       assertEquals(spectrum.regs.regA.Get(), 23);
       assertEquals(spectrum.regs.regA_.Get(), 1);
       assertEquals(spectrum.flg.GetCarry(), true);
       
       System.out.println("testEXX2 done...");
    }
    
    
    
    @Test
    public void testStack()
    {
       this.Init("Stack");
       spectrum.regs.regSP.Set(0);
       spectrum.LaunchMachineCode(30, 40000);
       System.out.println("Stack: " + spectrum.regs.regSP.Get());
       assertEquals(spectrum.regs.regSP.Get(), 65530);
    }
    
    @Test
    public void testCPL()
    {
       this.Init("CPL");
       spectrum.LaunchMachineCode(2, 40000);
       assertEquals(spectrum.regs.regA.Get(), 127);
       spectrum.LaunchMachineCode(1);
       assertEquals(spectrum.regs.regA.Get(), 129);
       assertEquals(spectrum.flg.GetCarry(), true);
        assertEquals(spectrum.flg.GetSign(), true);
     
    }

    @Test
    public void testPushPop()
    {
       this.Init("PushPop");
       spectrum.LaunchMachineCode(40, 40000);

            //ld sp,60000
            //ld ix, 65403
            //push ix
            //pop iy
            //push iy
            //pop bc
            //push bc
            //pop de
            //push de
            //pop hl
            //push hl
            //pop af       
       
        assertEquals(spectrum.regs.regSP.Get(), 60000);
        assertEquals(spectrum.regs.regIY.Get(), 65403);
        assertEquals(spectrum.regs.regIX.Get(), 65403);
        assertEquals(spectrum.regs.regBC.Get(), 65403);
        assertEquals(spectrum.regs.regDE.Get(), 65403);
        assertEquals(spectrum.regs.regHL.Get(), 65403);
        assertEquals(spectrum.regs.regA.Get(), 255);
        assertEquals(spectrum.ram.ReadRAM(60000 - 2), 123);
        assertEquals(spectrum.ram.ReadRAM(60000 - 1), 255);
        
        System.out.println("testPushPop done...");

    }
    
    @Test
    public void testLDIndexRegs()
    {
       this.Init("LDIndexRegs");
       spectrum.LaunchMachineCode(40, 40000);

        //ld ix,30000
        //ld (ix  - 33),250
        //ld iy,35000
        //ld (iy + 127),233
             
       assertEquals(spectrum.ram.ReadRAM(30000 - 33), 250);
       assertEquals(spectrum.ram.ReadRAM(30000 - 32), 0);
       assertEquals(spectrum.ram.ReadRAM(30000 - 34), 0);
       assertEquals(spectrum.ram.ReadRAM(35000 + 127), 233);
       assertEquals(spectrum.ram.ReadRAM(35000 + 128), 0);
       assertEquals(spectrum.ram.ReadRAM(35000 + 126), 0);
       
       //ld b,34
        //ld (ix + 120),b
        //ld (iy - 128),b
        
       assertEquals(spectrum.ram.ReadRAM(30000 + 120), 34);
       assertEquals(spectrum.ram.ReadRAM(35000 - 128), 34);
       
        //ld ix,40000
        //ld (ix + 0),123
        //ld (ix + 1),255
        //ld ix,(40000)
        //ld iy,(40000)
       
        assertEquals(spectrum.regs.regIX.Get(), 65403);
        assertEquals(spectrum.regs.regIY.Get(), 65403);
        
        //ld (25000),ix
        //ld (26000),iy
        
        assertEquals(spectrum.ram.ReadRAM(25000), 123);
        assertEquals(spectrum.ram.ReadRAM(25001), 255);
        assertEquals(spectrum.ram.ReadRAM(26000), 123);
        assertEquals(spectrum.ram.ReadRAM(26001), 255);
        
        //ld sp,ix
        //ld sp,iy
        
        assertEquals(spectrum.regs.regSP.Get(), 65403);
        
        System.out.println("testLDIndexRegs done...");
    }
    
    @Test
    public void testROM()
    {
       //RAMFileLoader fl = new RAMFileLoader("C:\\Documents and Settings\\Administrator\\JAVA\\ZXSpectrum emulator\\ZX Spectrum\\48k.bin", spectrum.ram, 0);
       //fl.Load();
        
        for (int j = 0; j < 20; j++)
        {
        //    spectrum.cpu.Parse();
        }
        
      
    }
    
    private void Init(String file)
    {
       spectrum.ram.ResetRAM();
       RAMLoadSaveFile fl = new RAMLoadSaveFile("C:\\Documents and Settings\\Administrator\\JAVA\\ZXSpectrum emulator\\ZX Spectrum\\" + file + ".bin", spectrum.ram, 40000);
       fl.Load();
    }

  
    
}