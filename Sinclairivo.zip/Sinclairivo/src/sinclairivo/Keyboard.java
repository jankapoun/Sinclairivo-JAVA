/*
 * Contains representation of ZXS keyboard
 * 
 */

package sinclairivo;

import javax.swing.*;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.Vector;
import java.util.Iterator;

/**
 * ZXS keyboard emulation class
 * @author Jan Kapoun, Mgr.
 */
public class Keyboard 
{
    private class Key
    {
        public int port1;
        public int port2;
        public int portOn1;
        public int portOn2;
        public int portOff1;
        public int portOff2;
        public String key;
    
        Key(String key, int port1, int port2, int on1, int on2,  int off1, int off2)
        {
            this.port1 = port1;
            this.port2 = port2;
            this.key = key;
            this.portOn1 = on1;
            this.portOn2 = on2;
            this.portOff1 = off1;
            this.portOff2 = off2;
            this.key = key;
        }
        
    }
    
    private Vector keys = new Vector();
    private Ports ports = null;
    
    private int on0 = 254;
    private int on1 = 253;
    private int on2 = 251;
    private int on3 = 247;
    private int on4 = 239;
    
    private int off0 = 1;
    private int off1 = 2;
    private int off2 = 4;
    private int off3 = 8;
    private int off4 = 16;
    
    
    public Keyboard(Ports ports)
    {
        this.ports = ports;
        
        if (Globals.ShowKeyboardDebug.equals("yes")) { this.Debug();}
        else if (!Globals.ShowKeyboardDebug.equals("no")){ System.err.println("ShowKeyboardDebug: bad argument!");}
       
        keys.add(new Key("Backspace", 65278, 61438, on0, on0, off0, off0));
        keys.add(new Key("Comma", 32766, 32766, on1, on3, off1, off3));
        keys.add(new Key("Period", 32766, 32766, on1, on2, off1, off2));
        keys.add(new Key("Slash",32766 , 65278, on1, on4, off1, off4));
        keys.add(new Key("NumPad /",32766 , 65278, on1, on4, off1, off4));
        keys.add(new Key("NumPad *",32766 , 65278, on1, on4, off1, off4));
        keys.add(new Key("NumPad -",32766 , 65278, on1, on4, off1, off4));
        keys.add(new Key("NumPad +",32766 , 65278, on1, on4, off1, off4));
        
        
        keys.add(new Key("Caps Lock",65278 , 63486, on0, on1, off0, off1));
        keys.add(new Key("Escape",65278 , 32766, on0, on0, off0, off0));
        
        keys.add(new Key("Down", 65278, 61438, on0, on4, off0, off4));
        keys.add(new Key("Up", 65278, 61438, on0, on3, off0, off3));
        keys.add(new Key("Right", 65278, 61438, on0, on2, off0, off2));
        keys.add(new Key("Left", 65278, 63486, on0, on4, off0, off4));
        
        keys.add(new Key("Shift", 65278, 0, on0, 255, off0, 255));
        keys.add(new Key("Z", 65278, 0, on1, 255, off1, 255));
        keys.add(new Key("X", 65278, 0, on2, 255, off2, 255));
        keys.add(new Key("C", 65278, 0, on3, 255, off3, 255));
        keys.add(new Key("V", 65278, 0, on4, 255, off4, 255));
        
        keys.add(new Key("A", 65022, 0, on0, 255, off0, 255));
        keys.add(new Key("S", 65022, 0, on1, 255, off1, 255));
        keys.add(new Key("D", 65022, 0, on2, 255, off2, 255));
        keys.add(new Key("F", 65022, 0, on3, 255, off3, 255));
        keys.add(new Key("G", 65022, 0, on4, 255, off4, 255));
        
        keys.add(new Key("Q", 64510, 0, on0, 255, off0, 255));
        keys.add(new Key("W", 64510, 0, on1, 255, off1, 255));
        keys.add(new Key("E", 64510, 0, on2, 255, off2, 255));
        keys.add(new Key("R", 64510, 0, on3, 255, off3, 255));
        keys.add(new Key("T", 64510, 0, on4, 255, off4, 255));
        
        keys.add(new Key("1", 63486, 0, on0, 255, off0, 255));
        keys.add(new Key("2", 63486, 0, on1, 255, off1, 255));
        keys.add(new Key("3", 63486, 0, on2, 255, off2, 255));
        keys.add(new Key("4", 63486, 0, on3, 255, off3, 255));
        keys.add(new Key("5", 63486, 0, on4, 255, off4, 255));
        keys.add(new Key("NumPad-1", 63486, 0, on0, 255, off0, 255));
        keys.add(new Key("NumPad-2", 63486, 0, on1, 255, off1, 255));
        keys.add(new Key("NumPad-3", 63486, 0, on2, 255, off2, 255));
        keys.add(new Key("NumPad-4", 63486, 0, on3, 255, off3, 255));
        keys.add(new Key("NumPad-5", 63486, 0, on4, 255, off4, 255));
        
        keys.add(new Key("0", 61438, 0, on0, 255, off0, 255));
        keys.add(new Key("9", 61438, 0, on1, 255, off1, 255));
        keys.add(new Key("8", 61438, 0, on2, 255, off2, 255));
        keys.add(new Key("7", 61438, 0, on3, 255, off3, 255));
        keys.add(new Key("6", 61438, 0, on4, 255, off4, 255));
        keys.add(new Key("NumPad-0", 61438, 0, on0, 255, off0, 255));
        keys.add(new Key("NumPad-9", 61438, 0, on1, 255, off1, 255));
        keys.add(new Key("NumPad-8", 61438, 0, on2, 255, off2, 255));
        keys.add(new Key("NumPad-7", 61438, 0, on3, 255, off3, 255));
        keys.add(new Key("NumPad-6", 61438, 0, on4, 255, off4, 255));
        
        keys.add(new Key("P", 57342, 0, on0, 255, off0, 255));
        keys.add(new Key("O", 57342, 0, on1, 255, off1, 255));
        keys.add(new Key("I", 57342, 0, on2, 255, off2, 255));
        keys.add(new Key("U", 57342, 0, on3, 255, off3, 255));
        keys.add(new Key("Y", 57342, 0, on4, 255, off4, 255));
        
        keys.add(new Key("Enter", 49150, 0, on0, 255, off0, 255));
        keys.add(new Key("L", 49150, 0, on1, 255, off1, 255));
        keys.add(new Key("K", 49150, 0, on2, 255, off2, 255));
        keys.add(new Key("J", 49150, 0, on3, 255, off3, 255));
        keys.add(new Key("H", 49150, 0, on4, 255, off4, 255));
        
        keys.add(new Key("Space", 32766, 0, on0, 255, off0, 255));
        keys.add(new Key("Ctrl", 32766, 0, on1, 255, off1, 255));
        keys.add(new Key("M", 32766, 0, on2, 255, off2, 255));
        keys.add(new Key("N", 32766, 0, on3, 255, off3, 255));
        keys.add(new Key("B", 32766, 0, on4, 255, off4, 255));
        
    }
    
    public void KeyDown(String keyText)
    {
           Iterator it = keys.iterator();
           while (it.hasNext())
           {
                Key key = (Key)it.next();
                
                if(keyText.equals(key.key))
                {
                    if (Globals.mapCursorAsKempston == true)
                    {
                        if (key.key.equals("Left")){ ports.SetPort(31, (ports.InPort(31) | 2)); return; }
                        if (keyText.equals("Right")){ ports.SetPort(31, (ports.InPort(31) | 1)); return; }
                        if (keyText.equals("Up")){ ports.SetPort(31, (ports.InPort(31) | 8)); return; }
                        if (keyText.equals("Down")){ ports.SetPort(31, (ports.InPort(31) | 4)); return; }
                        if (keyText.equals("Ctrl")){ ports.SetPort(31, (ports.InPort(31) | 16)); return; }
                    }
                    
                    ports.SetPort(key.port1, ports.InPort(key.port1) & key.portOn1);
                    if (key.port2 != 0) {ports.SetPort(key.port2, ports.InPort(key.port2) & key.portOn2);}
                }
           
           }
                     
    }
      

    public void KeyUp(String keyText)
    {
           Iterator it = keys.iterator();
           while (it.hasNext())
           {
                Key key = (Key)it.next();
                if(keyText.equals(key.key))
                {
                    if (Globals.mapCursorAsKempston == true)
                    {
                        if (key.key.equals("Left")){ ports.SetPort(31, (ports.InPort(31) & 29)); return; }
                        if (keyText.equals("Right")){ ports.SetPort(31, (ports.InPort(31) & 30)); return; }
                        if (keyText.equals("Up")){ ports.SetPort(31, (ports.InPort(31) & 23)); return; }
                        if (keyText.equals("Down")){ ports.SetPort(31, (ports.InPort(31) & 27)); return; }
                        if (keyText.equals("Ctrl")){ ports.SetPort(31, (ports.InPort(31) & 15)); return; }
                    }
                
                    ports.SetPort(key.port1, ports.InPort(key.port1) | key.portOff1);
                    if (key.port2 != 0) {ports.SetPort(key.port2, ports.InPort(key.port2) | key.portOff2);}
                }
                
           
           }
          
    }
    
    static JFrame theWindow = new JFrame("ZX Keyboard view");
    static Container wndContent = theWindow.getContentPane();
    static JTextArea TxtKBView = new JTextArea(); 

    public void Debug()
    {
        TxtKBView.setBounds(0, 0, 350, 300);
        TxtKBView.setFont(new Font("Verdana",20,10));
        wndContent.setLayout(new FlowLayout(FlowLayout.CENTER));
        wndContent.add(TxtKBView);
        theWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        theWindow.setBounds(100,100,400,250);
        theWindow.setVisible(true);

        DbgKeyboard dbg = new DbgKeyboard();
        dbg.launch();
    }
    
    public class DbgKeyboard extends Thread
    {
        public DbgKeyboard()
        {
            setDaemon(true);
        }
        
        public void launch()
        {
            Thread thr = new DbgKeyboard();
            thr.start();
        }
        
        
        public void run()
        {
            while(true)
            {
            TxtKBView.setText("Ports: \n\n");
            TxtKBView.append("65278\t65022\t64510\t63486\n");
            TxtKBView.append("CsshZXCV\tASDFG\tQWERT\t12345\n");
            TxtKBView.append("" + ports.InPort(65278) + "\t" + ports.InPort(65022) 
                    + "\t" + ports.InPort(64510) + "\t" + ports.InPort(63486));
            
            TxtKBView.append("\n-------------------------------------------------------------\n");            
            TxtKBView.append("61438\t57342\t49150\t32766\n");
            TxtKBView.append("09876\tPOIUY\tEntLKJH\tSpcSshMNB\n");
            TxtKBView.append("" + ports.InPort(61438) + "\t" + ports.InPort(57342) + 
                    "\t" + ports.InPort(49150) + "\t" + ports.InPort(32766));
            TxtKBView.append("\n-------------------------------------------------------------\n");            
            TxtKBView.append("\n\nKey pressed: ");
                    
//   private int CshZXCV = 255;      //65278;
//   private int ASDFG  = 255;        //65022;
//   private int QWERT = 255;       //64510
//   private int P12345 = 255;      //63486;
//   private int P09876 = 255;    //61438;
//   private int POIUY = 255;       //57342;
//   private int EntLKJH = 255;     //49150;
//   private int SpcSshMNB = 255;   //32766;
// 
                    
            
            try{ Thread.sleep(1000); }
            catch (Exception e){}
            }
        }
            
     }

}
    

