/*
 * Contains the representation of ZXS memory
 * 
 */

package sinclairivo;

/**
 *
 * @author Jan Kapoun, Mgr.
 */
public class RAM 
{
    private int ram[] = new int[65536];
    private MainWnd mainWindow;
    private VRAM vram = null;
    private Ports ports;

/**
 *
 * Creates a new instance of RAM, creates also a new object of VRAM
 * because ZXS memory 16384 - 22728 is VRAM. When writing to these
 * addresses, RAM object must also be able to call VRAM routines to 
 * ensure that the RAM values will be copied into the VRAM pixel array.
 */
    public RAM(MainWnd mainWindow, Ports ports)
    {
        this.mainWindow = mainWindow;
        this.ports = ports;
        vram = new VRAM(mainWindow, this, ports);
    }
  
/**
* Gets the actual int array representing the ZX RAM.
* @return ZX RAM int array
*/
    public int[] GetRAMArray()
    {
        return ram;
    }
    
/**
 * Gets the VRAM
 * @return VRAM
 */
    public VRAM GetVRAM()
    {
        return vram;
    }
    
/**
 * Writes into the RAM
 */
        public void WriteRAM(int addr, int b)
        {
            if (b > 255){ System.err.println("WriteRAM: Argument out of range!"); return;}
            //writing to the ROM is not possible
         //   if (addr < 16384) { System.err.println("WriteRAM: Attempt to write into ROM!");}
            
            if ((addr >= 16384) && (addr <= 65535)) { ram[addr] = b; }
            
            //writing to the pixels VRAM
            if ((addr >= 16384) && (addr <= 22527)) 
            {
                vram.WritePxlsToVRAM(addr, b);
                
            }
            //writing to the attributes VRAM
            if ((addr >= 22528) && (addr <= (22528 + 768))) 
            {
                vram.WriteAttribsToVRAM(addr, b);
           
            }
        }
        
/**
 * Writes into the ROM
 */
        public void WriteROM_NoCheck(int addr, int b)
        {
            if (b > 255){ System.err.println("WriteRAM: Argument out of range!"); return;}
            if ((addr >= 0) && (addr <= 65535)) { ram[addr] = b; }
            
             //writing to the pixels VRAM
            if ((addr >= 16384) && (addr <= 22527)) 
            {
                vram.WritePxlsToVRAM(addr, b);
                
            }
            //writing to the attributes VRAM
            if ((addr >= 22528) && (addr <= (22528 + 768))) 
            {
                vram.WriteAttribsToVRAM(addr, b);
           
            }
        }
                
    
/*
 * Reads from RAM
 * 
 */
 public int ReadRAM(int addr)
 {
       return ram[addr];
 }

/**
 * Fills a ZXS memory block with a specified value
 * used mainly for clearing the ZXS screen.
 * Used only for debugging purposes.
 * 
 */
 public void FillRAM(int from, int size, int with)
 {
    for (int i = from; i < from + size; i++ )
    {
        WriteRAM(i,with);
    }
 
 }

/**
 * Resets the RAM
 * Used only for debugging purposes.
 */ 
 public void ResetRAM()
 {
    this.FillRAM(0, 65536, 0);
 }
 
/**
 * Clears the VRAM (cls)
 * Used mainly for clearing the ZXS screen.
 * Used only for debugging purposes.
 * 
 */
  public void ClearVRAM()
  {
       FillRAM(16384, 6144, 0);
       FillRAM(22528, 768, 120);
  }
 

    
}
