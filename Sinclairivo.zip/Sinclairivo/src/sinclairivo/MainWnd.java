/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sinclairivo;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.io.*;
import java.awt.event.ActionListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.MenuListener;
import javax.swing.event.MenuEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;



/**
 *
 * @author Jan Kapoun, Mgr.
 */
public class MainWnd 
{
    
    private JFrame theMainWnd; 
    private Container wndContent;
    private Graphics2D g;
    private ZXMachine zxmachine;
    
    private enum Action{about, open, save, pause, reset, quality, exit, into_the_eagles_nest,
    highway_encounter,alien_encounter, chessmaster, tomahawk, stunt_car_racer,
    total_eclipse, total_eclipse2, snooker3D, quazatron, nether_earth,
    ikari_warriors, tetris, prometheus, zxrom, zxrommod, zxrombetadisk};
    
    /**
     * Constructor
     * @param name - the MainWindow's name
     */
    MainWnd(String name)
    {
        theMainWnd = new JFrame(name);
        CreateWindow();
    }
    
    
    
    public void setZXMachine(ZXMachine zxmachine)
    {
        this.zxmachine = zxmachine;
    }
    
    /**
     * Gets the MainWnd object.
     * @return MainWnd object.
     */
    public JFrame getTheMainWnd()
    {
        return theMainWnd;
    }
    
    /**
     * Gets the MainWnd's container.
     * @return the MainWnd's container.
     */
    public Container getWndContent()
    {
        return wndContent;
    }
    
    public Graphics2D getGraphics2D()
    {
        return g;
    }
    
    /**
     * Shows the welcome dialog.
     */
    public void ShowAboutDlg()
    {
        JOptionPane.showMessageDialog(getTheMainWnd(), 
                   "Sinclairivo - the ZX Spectrum emulator\n\nMade as an exercise in JAVA " +
                   "programming.\nUniversity of South Bohemia,\nDepartment of " +
                   "Computer Sciences\n\nContains a set of Spectrum ROMs and\n" +
                   "some original gaming software.\n\nPlease, select from the archive menu a game\n" +
                   "you want to play.\n\nMgr.Jan Kapoun, (c) 2008, \nJanKapoun (at) seznam.cz"); 
    }
    
    /**
     * Creates the main window and sets the Graphics2D object.
     */
    public void CreateWindow()
    {
        theMainWnd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        theMainWnd.setBounds(100,100,500,500);
        theMainWnd.setVisible(true);
        wndContent = theMainWnd.getContentPane();
        
        
        ImageIcon openIco = new ImageIcon("Icons/open.png");
        ImageIcon saveIco = new ImageIcon("Icons/save.png");
        ImageIcon pauseIco = new ImageIcon("Icons/pause.png");
        ImageIcon resetIco = new ImageIcon("Icons/reset.png");
        ImageIcon qualityIco = new ImageIcon("Icons/quality.png");
        ZXButton openBtn = new ZXButton(openIco,Action.open,"Open");
        ZXButton saveBtn = new ZXButton(saveIco, Action.save, "Save");
        ZXButton pauseBtn = new ZXButton(pauseIco, Action.pause, "Pause");
        ZXButton resetBtn = new ZXButton(resetIco,Action.reset, "Reset");
        ZXButton qualityBtn = new ZXButton(qualityIco, Action.quality, "Picture rendering quality");
        JToolBar toolbar = new JToolBar();
        
        toolbar.add(openBtn);
        toolbar.add(saveBtn);
        toolbar.add(pauseBtn);
        toolbar.add(resetBtn);
        toolbar.add(qualityBtn);
        toolbar.setFloatable(false);
        
        JMenuBar menuBar= new JMenuBar();
        menuBar.setBorder(BorderFactory.createEtchedBorder());
        JPanel statusBar = new JPanel();
        
        
        ZXSlider slider = new ZXSlider(Globals.sliderCPUspeedMin, Globals.sliderCPUspeedMax);
        slider.setSize(10,10);
        slider.setFocusable(false);
        slider.setValue(Globals.sliderCPUspeedMax - Globals.CPUspeed);
        
        JLabel sliderLabel = new JLabel("CPU speed: ");
        
        statusBar.add(sliderLabel);
        statusBar.add(slider);
        
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        
        
        ZXMenu menuFile = new ZXMenu("File");
        ZXMenu menuProgram = new ZXMenu("Archive");
        ZXMenu menuAbout = new ZXMenu("About");
        
        
        menuFile.add(new ZXMenuItem("Load file.. ",Action.open));
        menuFile.add(new ZXMenuItem("Save file..",Action.save));
        
        menuFile.add(new JSeparator());
        
        menuFile.add(new ZXMenuItem("Load original ZX ROM",Action.zxrom));
        menuFile.add(new ZXMenuItem("Load modified ZX ROM",Action.zxrommod));
        menuFile.add(new ZXMenuItem("Load GAMA ROM Betadisk",Action.zxrombetadisk));
        
        
        menuFile.add(new JSeparator());
        menuFile.add(new ZXCheckBoxMenuItem("Map cursor keys to Kempston", Globals.mapCursorAsKempston));
        menuFile.add(new JSeparator());
        
        menuFile.add(new ZXMenuItem("Exit",Action.exit));
        menuProgram.add(new ZXMenuItem("Eagle's nest",Action.into_the_eagles_nest));
        menuProgram.add(new ZXMenuItem("Highway Encounter",Action.highway_encounter));
        menuProgram.add(new ZXMenuItem("Alien Encounter",Action.alien_encounter));
        menuProgram.add(new ZXMenuItem("Ikari Warriors",Action.ikari_warriors));
        menuProgram.add(new ZXMenuItem("Stunt Car Racer simulation",Action.stunt_car_racer));
        menuProgram.add(new ZXMenuItem("Tomahawk helicopter simulation",Action.tomahawk));
        menuProgram.add(new ZXMenuItem("Tetris",Action.tetris));
        menuProgram.add(new ZXMenuItem("Chess game",Action.chessmaster));
        menuProgram.add(new ZXMenuItem("Total Eclipse",Action.total_eclipse));
        menuProgram.add(new ZXMenuItem("Total Eclipse 2",Action.total_eclipse2));
        menuProgram.add(new ZXMenuItem("Quazatron",Action.quazatron));
        
        menuProgram.add(new JSeparator());
        menuProgram.add(new ZXMenuItem("Prometheus assembler system",Action.prometheus));
        menuAbout.add(new ZXMenuItem("About",Action.about));
        menuBar.add(menuFile);
        menuBar.add(menuProgram);
        menuBar.add(menuAbout);
        menuBar.add(toolbar);
        
        wndContent.add(menuBar, BorderLayout.NORTH);
        wndContent.add(statusBar, BorderLayout.SOUTH);
        
        g = (Graphics2D)wndContent.getGraphics();
        
    }
 
    class ZXButton extends JButton implements ActionListener
    {
        private Action action;
        
        ZXButton(ImageIcon i, Action action, String tooltip)
        {
            super(i);
            this.action = action;
            this.addActionListener(this);
            this.setFocusable(false);
            this.setToolTipText(tooltip);
        }
        
        public void actionPerformed(ActionEvent e)
        {
            
            if (action == Action.reset){ Globals.reset = true; }
            if (action == Action.pause){ Globals.pause = !Globals.pause;}
            if (action == Action.quality){ Globals.quality = !Globals.quality;}
            
            if (action == Action.open)
            {
                
                JFileChooser open = new JFileChooser();
                open.setCurrentDirectory(new File("Files"));
                if (open.showOpenDialog(this) ==JFileChooser.CANCEL_OPTION ) return;
                JOptionPane dlg = new JOptionPane();
                if (open.getSelectedFile().getAbsolutePath().endsWith(".sna"))
                {
                    RAMLoadSaveFile.LoadSnapshot(open.getSelectedFile().getAbsolutePath(), 
                        zxmachine);
                }
                else if (open.getSelectedFile().getAbsolutePath().endsWith(".rom"))
                {
                    int loadValue = 0;
                    RAMLoadSaveFile.Load(open.getSelectedFile().getAbsolutePath(), 
                        zxmachine.ram, loadValue);
                }
                else
                {
                    int loadValue = Integer.parseInt(dlg.showInputDialog(this, "Start address:"));
                    RAMLoadSaveFile.Load(open.getSelectedFile().getAbsolutePath(), 
                        zxmachine.ram, loadValue);
                }
                
                
            }
            
            if (action == Action.save)
            {
                JFileChooser save = new JFileChooser();
                save.setCurrentDirectory(new File("Files"));
                if (save.showSaveDialog(this) ==JFileChooser.CANCEL_OPTION ) return;
                if (save.getSelectedFile().getAbsolutePath().endsWith(".sna"))
                {
                    RAMLoadSaveFile.SaveSnapshot(save.getSelectedFile().getAbsolutePath(), 
                        zxmachine);
                }
                else if (save.getSelectedFile().getAbsolutePath().endsWith(".rom"))
                {
                    RAMLoadSaveFile.Save(save.getSelectedFile().getAbsolutePath(), 
                        zxmachine.ram, 0, 16384);
                }
                else
                {
                
                    JOptionPane dlgStart = new JOptionPane();
                    JOptionPane dlgLength = new JOptionPane();
                    int saveStart = Integer.parseInt(dlgStart.showInputDialog("File start address:"));
                    int saveLength = Integer.parseInt(dlgLength.showInputDialog("File length: "));

                    RAMLoadSaveFile.Save(save.getSelectedFile().getAbsolutePath(), 
                            zxmachine.ram, saveStart, saveLength);
                }
            }
    
        }
    }
    
    class ZXMenu extends JMenu implements MenuListener, MouseListener
    {
        private Color background;
        
        ZXMenu(String s)
        {
            super(s);
            this.addMenuListener(this);
            this.addMouseListener(this);
            this.setOpaque(true);
        }

        public void mouseExited(MouseEvent e)
        {
            this.setBackground(background);
        }
        
        public void mouseEntered(MouseEvent e)
        {
            background = this.getBackground();
            this.setBackground(Color.LIGHT_GRAY);
        }
        
        public void mouseReleased(MouseEvent e){}
        public void mousePressed(MouseEvent e){}
        public void mouseClicked(MouseEvent e){}
        
        public void menuSelected(MenuEvent e)
        {
            Globals.pause = true;
            Globals.pauseScreenRefresh = true;
            while (Globals.paintingInProgress == true)
            {
                /**
                 * Waits for the screen to  finish its painting 
                 * so the menu gets not overpainted.
                 */
                try{ wait(10);} catch (Exception ex){} 
                
            }
            
        }
        
        public void menuCanceled(MenuEvent e)
        {
            Globals.pause = false;
            Globals.pauseScreenRefresh = false;
        }
        
        public void menuDeselected(MenuEvent e)
        {
            Globals.pause = false;
            Globals.pauseScreenRefresh = false;
        }
    }
    
    class ZXCheckBoxMenuItem extends JCheckBoxMenuItem implements ActionListener
    {
        ZXCheckBoxMenuItem(String s, boolean b)
        {
            super(s, b);
            this.addActionListener(this);
        }
        
        public void actionPerformed(ActionEvent e)
        {
            Globals.mapCursorAsKempston = this.isSelected();
            System.out.println("Kempston: " + this.isSelected());
        }
    
    }
    
    class ZXMenuItem extends JMenuItem implements ActionListener
    {
        Action action;
        ZXMenuItem(String s, Action action)
        {
            super(s);
            this.action = action;
            this.addActionListener(this);
        }
       
        public void actionPerformed(ActionEvent e)
        {
            if(action == Action.open)
            {
                JFileChooser open = new JFileChooser();
                open.setCurrentDirectory(new File("Files"));
                if (open.showOpenDialog(this) == (JFileChooser.CANCEL_OPTION)) return;
                JOptionPane dlg = new JOptionPane();
                if (open.getSelectedFile().getAbsolutePath().endsWith(".sna"))
                {
                    RAMLoadSaveFile.LoadSnapshot(open.getSelectedFile().getAbsolutePath(), 
                        zxmachine);
                }
                else if (open.getSelectedFile().getAbsolutePath().endsWith(".rom"))
                {
                    int loadValue = 0;
                    RAMLoadSaveFile.Load(open.getSelectedFile().getAbsolutePath(), 
                        zxmachine.ram, loadValue);
                }
                else
                {
                    int loadValue = Integer.parseInt(dlg.showInputDialog(this, "Start address:"));
                    RAMLoadSaveFile.Load(open.getSelectedFile().getAbsolutePath(), 
                        zxmachine.ram, loadValue);
                }
            }
            
            if(action == Action.save)
            {
                    JFileChooser save = new JFileChooser();
                    save.setCurrentDirectory(new File("Files"));
                    if (save.showSaveDialog(this) == JFileChooser.CANCEL_OPTION ) return;
                    if (save.getSelectedFile().getAbsolutePath().endsWith(".sna"))
                    {
                        RAMLoadSaveFile.SaveSnapshot(save.getSelectedFile().getAbsolutePath(), 
                            zxmachine);
                    }
                    else if (save.getSelectedFile().getAbsolutePath().endsWith(".rom"))
                    {
                        RAMLoadSaveFile.Save(save.getSelectedFile().getAbsolutePath(), 
                            zxmachine.ram, 0, 16384);
                    }
                    else
                    {

                        int saveStart = Integer.parseInt(JOptionPane.showInputDialog("File start address:"));
                        int saveLength = Integer.parseInt(JOptionPane.showInputDialog("File length: "));

                        RAMLoadSaveFile.Save(save.getSelectedFile().getAbsolutePath(), 
                                zxmachine.ram, saveStart, saveLength);
                      
                    }
             
            }
            
            if(action == Action.exit){ System.exit(0);}
            if (action == Action.about){ ShowAboutDlg(); }
            
            if(action == Action.ikari_warriors)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/ikari warriors.sna", zxmachine);
            }
        
            if(action == Action.alien_encounter)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/highway encounter 2.sna", zxmachine);
            }
            
            if(action == Action.chessmaster)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/chessmaster.sna",zxmachine);
            }
            
            if(action == Action.highway_encounter)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/highway encounter.sna", zxmachine);
            }
            
            if(action == Action.tomahawk)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/tomahawk.sna", zxmachine);
            }
            
            if(action == Action.into_the_eagles_nest)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/into the eagles nest.sna", zxmachine);
            }
            
            if(action == Action.stunt_car_racer)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/stunt car racer.sna", zxmachine);
            }
            
            if(action == Action.tetris)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/tetris.sna", zxmachine);
            }
            
            if(action == Action.total_eclipse)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/total eclipse.sna", zxmachine);
            }
            
            if(action == Action.total_eclipse2)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/total eclipse 2.sna", zxmachine);
            }
            
            if(action == Action.quazatron)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/quazatron.sna", zxmachine);
            }
            
             if(action == Action.prometheus)
            {
                RAMLoadSaveFile.LoadSnapshot("Files/prometheus.sna", zxmachine);
            }
           
            
            if(action == Action.zxrom)
            {
                    RAMLoadSaveFile.Load("Files/zx spectrum ROM.rom", 
                        zxmachine.ram, 0);
                    Globals.reset = true;
            }
            
            if(action == Action.zxrommod)
            {
                    RAMLoadSaveFile.Load("Files/zx spectrum ROM modified.rom", 
                        zxmachine.ram, 0);
                    Globals.reset = true;
            }
            
            if(action == Action.zxrombetadisk)
            {
                    RAMLoadSaveFile.Load("Files/zx spectrum GAMA ROM.rom", 
                        zxmachine.ram, 0);
                    Globals.reset = true;
            }
        
        }
    }
    
    class ZXSlider extends JSlider  implements ChangeListener
    {
        
        ZXSlider(int x, int y)
        {
            super(x, y);
            this.addChangeListener(this);
            this.majorTickSpacing = 1;
            
            this.setToolTipText("Slide to change the CPU speed");
            
        }
        
        
        public void stateChanged(ChangeEvent e)
        {
            Globals.CPUspeed = Globals.sliderCPUspeedMax - this.getValue() + 1;
        }
    }
    
}
