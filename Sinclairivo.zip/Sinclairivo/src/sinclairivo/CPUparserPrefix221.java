/*
 * Parses instructions following the 221 prefix code.
 * 
 */

package sinclairivo;

/**
 * Parses instructions following the 221 prefix code.
 * @author Jan Kapoun, Mgr.
 */
public class CPUparserPrefix221 
{
    private CPUroutines cpu;
    private Registers regs;
    private CPUparserPrefix221_203 prefix221_203;
    private int code;

    
    public CPUparserPrefix221(CPUroutines cpu, Registers regs)
    {
        this.cpu = cpu;
        this.regs = regs;
        prefix221_203 = new CPUparserPrefix221_203(cpu, regs);
    }
    
    public void Parse()
    {
        cpu.Refresh_R(); //obnov R registr
        code = cpu.Fetch();

        switch (code)
        {
            
            case 104:/*LD LX,B */
                {
                    cpu.LD(regs.regLX, regs.regB);
                }
                break;
            
            case 105:/*LD LX,C */
                {
                    cpu.LD(regs.regLX, regs.regC);
                }
                break;
                
            case 106:/*LD LX,D */
                {
                    cpu.LD(regs.regLX, regs.regD);
                }
                break;
                
            case 107:/*LD LX,E */
                {
                    cpu.LD(regs.regLX, regs.regE);
                }
                break;
                
            case 108:/*LD LX,HX */
                {
                    cpu.LD(regs.regLX, regs.regHX);
                }
                break;
            
            case 109:/*LD LX,LX */
                {
                    cpu.LD(regs.regLX, regs.regLX);
                }
                break;
            
            case 111:/*LD LX,A */
                {
                    cpu.LD(regs.regLX, regs.regA);
                }
                break;
                
            case 96:/*LD HX,B */
                {
                    cpu.LD(regs.regHX, regs.regB);
                }
                break;
            
            case 97:/*LD HX,C */
                {
                    cpu.LD(regs.regHX, regs.regC);
                }
                break;
                
            case 98:/*LD HX,D */
                {
                    cpu.LD(regs.regHX, regs.regD);
                }
                break;
                
            case 99:/*LD HX,E */
                {
                    cpu.LD(regs.regHX, regs.regE);
                }
                break;
                
            case 100:/*LD HX,HX */
                {
                    cpu.LD(regs.regHX, regs.regHX);
                }
                break;
            
            case 101:/*LD HX,LX */
                {
                    cpu.LD(regs.regHX, regs.regLX);
                }
                break;
            
            case 103:/*LD HX,A */
                {
                    cpu.LD(regs.regHX, regs.regA);
                }
                break;    
                
            case 38:/*LD HX,N*/
                {
                    cpu.LD_REG8_NN(regs.regHX);
                }
                break;
            
            case 46:/*LD LX,N*/
                {
                    cpu.LD_REG8_NN(regs.regLX);
                }
                break;
            
            case 69:/*LD B,LX*/
                {
                    cpu.LD(regs.regB, regs.regLX);
                }
                break;
            
            case 77:/*LD C,LX*/
                {
                    cpu.LD(regs.regC, regs.regLX);
                }
                break;
                
            case 85:/*LD D,LX*/
                {
                    cpu.LD(regs.regD, regs.regLX);
                }
                break;
                
             case 93:/*LD E,LX*/
                {
                    cpu.LD(regs.regE, regs.regLX);
                }
                break;
                
             case 125:/*LD A,LX*/
                {
                    cpu.LD(regs.regA, regs.regLX);
                }
                break;
                
             case 68:/*LD B,HX*/
                {
                    cpu.LD(regs.regB, regs.regHX);
                }
                break;
            
            case 76:/*LD C,HX*/
                {
                    cpu.LD(regs.regC, regs.regHX);
                }
                break;
                
            case 84:/*LD D,HX*/
                {
                    cpu.LD(regs.regD, regs.regHX);
                }
                break;
                
             case 92:/*LD E,HX*/
                {
                    cpu.LD(regs.regE, regs.regHX);
                }
                break;
                
             case 124:/*LD A,HX*/
                {
                    cpu.LD(regs.regA, regs.regHX);
                }
                break;   
                 
            case 36:/*INC HX*/
                {
                    cpu.INC(regs.regHX);
                }
                break;
            
            case 37:/*DEC HX*/
                {
                    cpu.DEC(regs.regHX);
                }
                break;
            
            case 44:/*INC LX*/
                {
                    cpu.INC(regs.regLX);
                }
                break;
            
            case 45:/*DEC LX*/
                {
                    cpu.DEC(regs.regLX);
                }
                break;
                
            case 132:/*ADD A, HX*/
                {
                    cpu.ADD(regs.regA, regs.regHX);
                }
                break;
            
            case 133:/*ADD A, LX*/
                {
                    cpu.ADD(regs.regA, regs.regLX);
                }
                break;
                
            case 140:/*ADC A, HX*/
                {
                    cpu.ADC(regs.regA, regs.regHX);
                }
                break;    
                
            case 141:/*ADC A, LX*/
                {
                    cpu.ADC(regs.regA, regs.regLX);
                }
                break;    
                
            case 148:/*SUB A, HX*/
                {
                    cpu.SUB(regs.regA, regs.regHX);
                }
                break;    
                
            case 149:/*SUB A, LX*/
                {
                    cpu.SUB(regs.regA, regs.regLX);
                }
                break;      
                
                
            case 156:/*SBC A, HX*/
                {
                    cpu.SBC(regs.regA, regs.regHX);
                }
                break;    
                
            case 157:/*SBC A, LX*/
                {
                    cpu.SBC(regs.regA, regs.regLX);
                }
                break;      
                
            case 164:/*AND HX*/
                {
                    cpu.AND(regs.regA, regs.regHX);
                }
                break;
    
            case 165:/*AND LX*/
                {
                    cpu.AND(regs.regA, regs.regLX);
                }
                break;
            
                
            case 166:/*AND (IX + N)*/
                {
                    cpu.AND_RegA_FromWherePointsIX_IY_Shift(regs.regIX);
                }
                break;
                
            case 172:/*XOR HX*/
                {
                    cpu.XOR(regs.regA, regs.regHX);
                }
                break;
    
            case 173:/*XOR LX*/
                {
                    cpu.XOR(regs.regA, regs.regLX);
                }
                break;
                

            case 180:/*OR HX*/
                {
                    cpu.OR(regs.regA, regs.regHX);
                }
                break;
    
            case 181:/*OR LX*/
                {
                    cpu.OR(regs.regA, regs.regLX);
                }
                break;
        
                
            case 182:/*OR (IX + N)*/
                {
                    cpu.OR_RegA_FromWherePointsIX_IY_Shift(regs.regIX);
                }
                break;

            case 174:/*XOR (IX + N)*/
                {
                  cpu.XOR_RegA_FromWherePointsIX_IY_Shift(regs.regIX);
                  }
                break;
                
            case 188:/*CP HX*/
                {
                    cpu.CP(regs.regA, regs.regHX);
                }
                break;
    
            case 189:/*CP LX*/
                {
                    cpu.CP(regs.regA, regs.regLX);
                }
                break;
                

            case 190: /*CP (IX + N)*/
                {
                    cpu.CP_RegA_FromWherePointsIX_IY_Shift(regs.regIX);
                }
                break;

            case 52: /*INC (IX + N)*/
                {
                    cpu.INC_WherePointsIX_Shift(regs.regIX);
                }
                break;

            case 53: /*DEC (IX + N)*/
                {
                    cpu.DEC_WherePointsIX_Shift(regs.regIX);
                }
                break;

             case 134: /*ADD A,(IX + N)*/
                {
                    cpu.ADD_A_IX_IY_Plus_N(regs.regA, regs.regIX);
                }
                break;

            case 142: /*ADC A,(IX + N)*/
                {
                    cpu.ADC_A_IX_IY_Plus_N(regs.regA, regs.regIX);
                }
                 break;

             case 150: /*SUB(IX + N)*/
                 {
                     cpu.SUB_A_IX_IY_Plus_N(regs.regA, regs.regIX);
                 }
                 break;

             case 158: /*SBC A,(IX + N)*/
                 {
                     cpu.SBC_A_IX_IY_Plus_N(regs.regA, regs.regIX);
                 }
                 break;

            case 227:    /* EX (SP),IX */
                {
                    cpu.EX_ToWherePointsSP_IX();
                }
                break;

            case 249:  /* LD SP,IX*/
                {
                    cpu.LD(regs.regSP, regs.regIX, 10);
                }
                break;

            case 33: /*LD IX,NN*/
                {
                    cpu.LD_REG16_NN(regs.regIX, 14);
                }
                break;

            case 34:  /* LD (nn),IX*/
                {
                    cpu.LD_MEM_REG16(regs.regIX, 20);
                }
                break;

            case 42: /*LD IX,(NN)*/
                {
                    cpu.LD_REG16_FromWherePointsOp(regs.regIX, 20);
                }
                break;

            case 70: /*LD B,(IX + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regB, regs.regIX);
                }
                break;

             case 78: /*LD C,(IX + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regC, regs.regIX);
                }
                break;

            case 86: /*LD D,(IX + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regD, regs.regIX);
                }
                break;

            case 94: /*LD E,(IX + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regE, regs.regIX);
                }
                break;

            case 102: /*LD H,(IX + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regH, regs.regIX);
                }
                break;

            case 110: /*LD L,(IX + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regL, regs.regIX);
                }
                break;

            case 126: /*LD A,(IX + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regA, regs.regIX);
                }
                break;

             case 112: /*LD (IX + E),B*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIX, regs.regB);
                }
                break;

             case 113: /*LD (IX + E),C*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIX, regs.regC);
                }
                break;

            case 114: /*LD (IX + E),D*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIX, regs.regD);
                }
                break;

            case 115: /*LD (IX + E),E*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIX, regs.regE);
                }
                break;

            case 116: /*LD (IX + E),H*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIX, regs.regH);
                }
                break;

            case 117: /*LD (IX + E),L*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIX, regs.regL);
                }
                break;

            case 119: /*LD (IX + E),A*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIX, regs.regA);
                }
                break;

             case 54: /*LD (IX + E),N*/
                {
                    cpu.LD_ToWherePointsIndexReg_NN(regs.regIX);
                }
                break;

            case 35: /*INC IX*/
                {
                    cpu.INC_IndexReg(regs.regIX);
                }
                break;

            case 43: /*DEC IX*/
                {
                    cpu.DEC_IndexReg(regs.regIX);
                }
                break;

            case 9: /*ADD IX,BC*/
                {
                    cpu.ADD_IX_REG16(regs.regIX,regs.regBC);
                }
                break;

            case 25: /*ADD IX,DE*/
                {
                    cpu.ADD_IX_REG16(regs.regIX,regs.regDE);
                }
                break;

            case 41: /*ADD IX,IX*/
                {
                    cpu.ADD_IX_REG16(regs.regIX,regs.regIX);
                }
                break;

            case 57: /*ADD IX,SP*/
                {
                    cpu.ADD_IX_REG16(regs.regIX,regs.regSP);
                }
                break;

            case 229: /*PUSH IX*/
                {
                    cpu.PUSH_IndexReg(regs.regIX);
                }
                break;

            case 225: /*POP IX*/
                {
                    cpu.POP_IndexReg(regs.regIX);
                }
                break;

            case 233: /*JP (IX)*/
                {
                    cpu.JP_Index(regs.regIX);
                }
                break;

            case 203:
                {
                    prefix221_203.Parse();
                }
                break;

   
            default:
            {
                System.err.println("Prefix 221, instruction not supported, code: " + code + ", address: " + regs.regPC);
            }
        }
     }

}
