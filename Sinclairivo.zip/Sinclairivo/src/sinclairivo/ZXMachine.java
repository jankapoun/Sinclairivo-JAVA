
package sinclairivo;
import javax.swing.*;
import java.awt.*;

/**
 * This class contains the whole ZX Spectrum machine incl keyboard, screen etc...
 * @author Jan Kapoun, Mgr.
 */
public class ZXMachine 
{
    
    public Registers regs; 
    public Flags flg;
    public RAM ram;
    public Ports ports;
    public CPUroutines r;
    public CPUparser cpu; 
    
   /**
    * Constructor.
    * @param mainWindow - a window on which is to be displayed.
    */
   ZXMachine(MainWnd mainWindow)
   {
      CreateZXSMachine(mainWindow);
      mainWindow.setZXMachine(this);
   }
    
   /**
    * Creates one single ZX Spectrum machine.
    * @param mainWindow - a window on which to display.
    */
    public void CreateZXSMachine(MainWnd mainWindow)
    {
        
        regs = new Registers();
        flg = new Flags(regs);
        ports = new Ports();
        ram = new RAM(mainWindow, ports);
        r = new CPUroutines(ram, flg, ports, regs);
        cpu = new CPUparser(r, regs);

        ram.ClearVRAM();
        regs.regPC.Set(0);
        regs.regSP.Set(0);
        
        Keyboard kbd = new Keyboard(ports);
        KeyHandler kHandler = new KeyHandler(kbd);
        mainWindow.getTheMainWnd().addKeyListener(kHandler); 
       
        LoadROM();
    }
   
    
    /**
     * Launches machine code.
     * @param iCount number of instructions to launch.
     * @param PCreg from where shall the execution start.
     */
    public void LaunchMachineCode(int iCount, int PCreg)
    {
        regs.regPC.Set(PCreg);
        launchMCode(iCount);
    }

    /**
     * Launches specified number of instructions.
     * @param iCount number of instructions to launch.
     */
    public void LaunchMachineCode(int iCount)
    {
        launchMCode(iCount);
    }
    
    
    private void launchMCode(int iCount)
    {
        for (int j = 0; j < iCount; j++)
        {
            cpu.Parse();
            IMCallOnRequest();
            
        }
    
    }
    
    /**
     * Calls an interrupt when needed.
     */
    private void IMCallOnRequest()
    {
        if (r.GetInterruptRequest() == true)
        {
            r.CallIM();
        }
        
    }

        
    /**
     * Resets the whole machine.
     */
    public void ResetMachine()
    {
        Globals.reset = true;
        LaunchMachineCode(700000,0);
    }
    
    
   /**
    * Loads the Spectrum ROM.
    */
    public void LoadROM()
    {
        RAMLoadSaveFile.Load("Files/zx spectrum ROM.rom", ram, 0);
    }
    
}
