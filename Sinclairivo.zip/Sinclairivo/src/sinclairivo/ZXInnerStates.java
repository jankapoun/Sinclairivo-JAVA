/*
 * This is a debugging class.
 * Shows the states of registers, flags, ports...
 */

package sinclairivo;

import javax.swing.*;
import java.awt.*;


/**
 * This is a debugging class.
 * Shows the states of registers, flags, ports...
 * @author Jan Kapoun, Mgr.
 */

    
public class ZXInnerStates extends Thread
{
    static JFrame wnd = new JFrame("ZX Inner States");
    static Container wndCnt = wnd.getContentPane();
    static JTextArea txtWnd = new JTextArea(); 
    
    private Registers regs;
    private Flags flags;
    private Ports ports;
    
    public ZXInnerStates(Registers regs, Flags flags, Ports ports )
    {
        this.regs = regs;
        this.flags = flags;
        this.ports = ports;
        
        txtWnd.setBounds(0, 0, 350, 300);
        txtWnd.setFont(new Font("Verdana",20,10));
        wndCnt.setLayout(new FlowLayout(FlowLayout.CENTER));
        wndCnt.add(txtWnd);
        wnd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        wnd.setBounds(600,400,400,300);
        wnd.setVisible(true);
        
        setDaemon(true);
        this.start();
    }
    
    public void run()
    {
        while(true)
        {
//        txtWnd.setText("A: " + regs.regA.Get() + "\n" + "A: " + this.DecToBin(regA) + 
//                "\tF: " + regF.Get() + 
//                "\tB: " + regB.Get()
//                + "\tC: " + regC.Get() + "\nD: " + regD.Get() + 
//                "\tE: " + regE.Get() + "\tH: " + regH.Get() + 
//                "\tL: " + regL.Get());
//        txtWnd.append("\n-------------------------------------------------------------------\n");
//        txtWnd.append("A': " + regA_.Get() + "\tF': " + regF_.Get() + 
//                "\tB': " + regB_.Get()
//                + "\tC': " + regC_.Get() + "\nD': " + regD_.Get() + 
//                "\tE': " + regE_.Get() + "\tH': " + regH_.Get() + 
//                "\tL': " + regL_.Get());
//        txtWnd.append("\n-------------------------------------------------------------------\n");            
//        txtWnd.append("BC: " + regBC.Get() + "\tDE: " + regDE.Get()
//                + "\tHL: " + regHL.Get());
//        txtWnd.append("\n");
//        txtWnd.append("BC': " + regBC_.Get() + "\tDE': " + regDE_.Get()
//                + "\tHL': " + regHL_.Get());
//        txtWnd.append("\n-------------------------------------------------------------------\n");
//        txtWnd.append("IX: " + regIX.Get() + "\tIY: " + regIY.Get() +
//                 "\nLX: " + regLX.Get() + "\tLY: " + regLY.Get() +
//                 "\nHX: " + regHX.Get() + "\tHY: " + regHY.Get());
//        txtWnd.append("\n-------------------------------------------------------------------\n");
//        txtWnd.append("SP: " + regSP.Get() + "\tPC: " + regPC.Get() +
//                 "\tR: " + regR.Get() + "\tI: " + regI.Get());
//        txtWnd.append("\n-------------------------------------------------------------------\n");
//        txtWnd.append("IFF: " + regIFF);
//

        try{ Thread.sleep(1000); }
        catch (Exception e){}
        }
    }

    
   /**
    * Translates a decimal number into a String representing a binary number.
    * @param reg
    * @return 
    */
    public String DecToBin(Reg8 reg)
    {
        String s = "";
        if ((reg.Get() & 128) == 128){ s = s + "1";} else {s = s + "0";}
        if ((reg.Get() & 64) == 64){ s = s + "1";} else {s = s + "0";}
        if ((reg.Get() & 32) == 32){ s = s + "1";} else {s = s + "0";}
        if ((reg.Get() & 16) == 16){ s = s + "1";} else {s = s + "0";}
        if ((reg.Get() & 8) == 8){ s = s + "1";} else {s = s + "0";}
        if ((reg.Get() & 4) == 4){ s = s + "1";} else {s = s + "0";}
        if ((reg.Get() & 2) == 2){ s = s + "1";} else {s = s + "0";}
        if ((reg.Get() & 1) == 1){ s = s + "1";} else {s = s + "0";}
        return s;
    }
}
