/**
 * Emulates the ZXS 8bit registers.
 * @author Jan Kapoun, Mgr.
 */

package sinclairivo;

public class Reg8
{
    private int value = 0;
/**
 * New instance of Reg8
 * 
 */
    Reg8(int value)
    {
        if ((value > 255) || (value < 0))
        { 
            System.err.println("Reg8, constructor, argument out of range: " + value); 
            return;
        }
        
        this.value = value;
    }
    
/**
 * Adds the specified number
 * 
 */
    public int Plus(int plus)
    {
        if ((plus > 255) || (plus < 0))
        {
            System.err.println("Reg8, Plus method, argument out of range: " + plus); 
            return -1;
        }
        value += plus;
        if (value > 255){ value = value - 256; }
        return value;
    }

/**
* Substracts the specified number
* 
*/
    public int Minus(int minus)
    {
        if (minus > 255 || (minus < 0))
        {
            System.err.println("Reg8, Minus method, argument out of range: " + minus); 
            return -1;
        }
        value -= minus;
        if (value < 0){ value = value + 256; }
        return value;
    }
    
/**
 * Returns the actual value of this Reg8
 * 
 */
    public int Get()
    {
        return value;
    }

 /**
 * Sets the Reg8 to the specified value
 * 
 */
    public int Set(int x)
    {
      if ((x > 255) || (x < 0))
      {
          System.err.println("Reg8, Set method, argument out of range: " + x); 
          System.err.println("object:" + this.toString());
          return -1;
      }
      value = x;
      return value;
    }
 
 /**
 * Increases the register by 1.
 */
    public int Inc()
    {
        Plus(1);
        return value;
    }
 
/**
 * Decreases the register by 1.
 */
    public int Dec()
    {
        Minus(1);
        return value;
    }

}


