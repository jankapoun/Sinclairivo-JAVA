/*
 * The Main class, runs the whole emulator
 * 
 */

package sinclairivo;
import javax.swing.*;
import java.awt.*;

/**
 *  Runs the whole project
 * @author Jan Kapoun, Mgr.
 */
public class Main 
{

    
    /**
     * Runs the whole system.
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       
        MainWnd mainWindow = new MainWnd("Sinclairivo");
        ZXMachine zxmachine = new ZXMachine(mainWindow);
        mainWindow.getTheMainWnd().setVisible(true);
        mainWindow.getTheMainWnd().invalidate();
        
        zxmachine.ResetMachine();
        mainWindow.ShowAboutDlg();
        
        RAMLoadSaveFile.LoadSnapshot("Files/highway encounter.sna", zxmachine);
            
             while(true)
             {
                zxmachine.LaunchMachineCode(1);
                
             }
         
         
         
    }
    
    
}
