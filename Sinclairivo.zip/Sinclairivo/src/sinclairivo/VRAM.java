/*
 * VRAM class, represents the ZXS screen and VRAM
 * 
 */

package sinclairivo;

import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;


/**
 * VRAM class, represents the ZXS screen and VRAM
 * @author Jan Kapoun, Mgr.
 */
public class VRAM 
{
/*
 * BufferedImage - image representing the ZXS screen/video ram
 * WritableRaster - a special object encapsulating the actual VRAM data
 * VRAMdata - the actual VRAM data in RGB values (3 bytes per pixel)
 * ram - object that provides access to the RAM
 * IsFlash - signal, should the blinking attributes be redrawn?
 * flashPeriod - flash frequency
 */
    
  private BufferedImage bImage = new BufferedImage(256,192,BufferedImage.TYPE_3BYTE_BGR);
  private WritableRaster wRaster = bImage.getRaster();
  private MainWnd mainWindow;
  private int VRAMdata[] = new int[256 * 192 * 3];
  private RAM ram;
  private Ports ports;
  private boolean IsFlash;   //signal, zda se maji prekreslit blikajici atributy
  private int flashPeriod;   //sem se uklada pocet preruseni, aby se vedelo, kdy se ma bliknout
  
  private Color white = new Color(220, 220, 220);
  private Color yellow = new Color(220, 220, 7);
  private Color cyan = new Color(18, 200, 220);
  private Color green = new Color(45, 200, 17);
  private Color magenta = new Color(234, 16, 239);
  private Color red = new Color(200, 24, 13);
  private Color blue = new Color(16, 16, 200);
  
/**
 * Creates a new instance of VRAM
 */ 
  VRAM(MainWnd mainWindow, RAM ram, Ports ports)
  {
        this.mainWindow = mainWindow;
        this.ram = ram;
        this.ports = ports;
        wRaster.setPixels(0, 0, 256, 192, VRAMdata); //copy the VRAM data into the raster
        LaunchScreenRefresh();
  }
  
  
/*
 * Draws the video pixel data according to the RAM content
 */
  public void WritePxlsToVRAM(int addr, int b)
  {
      VRAMDrawByte(addr, b);
  }

/*
 * Colors the video pixel data with the accorging RAM attributes
 */
  public void WriteAttribsToVRAM(int addr, int b)
  {
      VRAMDrawByteAccordToAttrbs(addr);
  }
  
/*
 * Copies the VRAMdata into the WritableRaster and
 * draws the VRAM to the screen
 */
  private void DrawVRAM()
  {
      int width = mainWindow.getWndContent().getWidth();
      int height = mainWindow.getWndContent().getHeight();
      int widthBorder = width/100*10;
      int heightBorder = height/100*15;
              
      if (Globals.pauseScreenRefresh == true){return;}
      wRaster.setPixels(0, 0, 256, 192, VRAMdata); //copy the VRAM data into the raster
      Graphics2D gr = (Graphics2D)mainWindow.getWndContent().getGraphics();
      if (Globals.quality == false){ gr.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_DEFAULT);}
      if (Globals.quality == true){ gr.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);}
      gr.drawImage(bImage, widthBorder, heightBorder, width - widthBorder, height - heightBorder, 0, 0, 256, 192, null);
      SetBorder();
  }
 
  /**
   * Sets the color of border.
   */
  public void SetBorder()
  {
      if (ports.border == 0){ mainWindow.getWndContent().setBackground(Color.BLACK);}
      if (ports.border == 1){ mainWindow.getWndContent().setBackground(blue);}
      if (ports.border == 2){ mainWindow.getWndContent().setBackground(red);}
      if (ports.border == 3){ mainWindow.getWndContent().setBackground(magenta);}
      if (ports.border == 4){ mainWindow.getWndContent().setBackground(green);}
      if (ports.border == 5){ mainWindow.getWndContent().setBackground(cyan);}
      if (ports.border == 6){ mainWindow.getWndContent().setBackground(yellow);}
      if (ports.border == 7){ mainWindow.getWndContent().setBackground(white);}
  
  }
  
 /*
 * Sets the individual pixel data in VRAMdata[]
 */ 
  private void SetPixel(int x, int y, Color clr)  
  {                                            
       int pointer = (y * 256 * 3) + (x * 3);
       VRAMdata[pointer] = clr.getRed();
       VRAMdata[pointer + 1] = clr.getGreen();
       VRAMdata[pointer + 2] = clr.getBlue();
  }

 /*
 *  Tests the individual bits in a given byte and paints 
 *  dots (pixels) accordingly
 */ 
  private void VRAMDrawByte(int addr, int b)
  {
       
       AtbsAdrAndCoords AtbsAddressAndCoords = VRAMComputeXY(addr); //according to the given address, find the x, y coords and attribute address
       AttribsBunch AtbsColors = VRAMGetAttribs(AtbsAddressAndCoords.AttribsAdr);
       int x = AtbsAddressAndCoords.x;
       int y = AtbsAddressAndCoords.y;
       Color ink = AtbsColors.ink;
       Color paper = AtbsColors.paper;
       
       Color interm;           //stores values for flash
      // boolean bright;
      // boolean flash;

       //if the attribute is to be flashed now, exchange the paper and ink color
       if ((IsFlash == true) & (AtbsColors.flash == true)) { interm = ink; ink = paper; paper = interm; } 

       int shift = 0;         //x-axis shift for the individual dots to be painted
       if ((b & 128) != 0) { SetPixel(x, y, ink); }
       else { SetPixel(x, y, paper); }
       shift++;

       if ((b & 64) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 32) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 16) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 8) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 4) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 2) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 1) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
   }
  
 /*
 *  This method is called to ensure flashing
 */ 
  private void VRAMFlash()
  {
       int addr = 22528;
       int b;

       for (int i = 0; i < 768; i++)
       {
           b = ram.ReadRAM(addr + i);
           if ((b & 128) == 128)
           {
               VRAMDrawByteAccordToAttrbs(addr + i);
           }
       }

  }

 /*
 *  Redraw pixels in 8x8 square so they correspond to their attributes
 */ 
  private void VRAMDrawByteAccordToAttrbs(int addr)
  {
            
            int pxlsAddr = 16384;
            addr = (addr - 22528);
            int x = (addr % 32);
            int y = (addr / 32);

            if (y < 8) { pxlsAddr = (16384 + (32 * y) + x); }
            else if (y < 16) 
            {
                y -= 8;     //korekce y pro prechod mezi tretinami
                pxlsAddr = (18432 + (32 * y) + x); 
            }
            else 
            {
                y -= 16;    //korekce y pro prechod mezi tretinami
                pxlsAddr = (20480 + (32 * y) + x); 
            }

            for (int i = 0; i < 2048; i = i + 256) //prekresli vsech 8 bytu
            {
                VRAMDrawByte((pxlsAddr + i),ram.ReadRAM((pxlsAddr + i)));
            }
        } 
  
  
/*
 *  Returns paper and ink colors, flash and bright (attributes)
 *  which are bound with a given pixel address
 */ 
  private AttribsBunch VRAMGetAttribs(int addr)
  {
       AttribsBunch abts = new AttribsBunch();
       int attribute = ram.ReadRAM(addr);

       int InkData = (attribute & 7);
       int PaperData = (attribute & 56);

       if ((attribute & 128) != 0) { abts.flash = true; } 
       else { abts.flash = false; }

       if ((attribute & 64) != 0) { abts.bright = true; } 
       else { abts.bright = false; }

       switch (InkData)
       {
                case 0:
                    abts.ink = Color.BLACK;
                    break;
                case 1:
                    if (abts.bright == true) abts.ink = Color.BLUE.brighter();
                    else abts.ink = blue;
                    break;
                case 2:
                    if (abts.bright == true) abts.ink = Color.RED.brighter();
                    else abts.ink = red;
                    break;
                case 3:
                    if (abts.bright == true) abts.ink = Color.MAGENTA.brighter();
                    else abts.ink = magenta;
                    break;
                case 4:
                    if (abts.bright == true) abts.ink = Color.GREEN.brighter();
                    else abts.ink = green;
                    break;
                case 5:
                    if (abts.bright == true) abts.ink = Color.CYAN.brighter();
                    else abts.ink = cyan;
                    break;
                case 6:
                    if (abts.bright == true) abts.ink = Color.YELLOW.brighter();
                    else abts.ink = yellow;
                    break;
                case 7:
                    if (abts.bright == true) abts.ink = Color.WHITE.brighter();
                    else abts.ink = white;
                    break;
            }

            switch (PaperData)
            {
                case 0:
                    abts.paper = Color.BLACK;
                    break;
                case 8:
                    if (abts.bright == true) abts.paper = Color.BLUE.brighter();
                    else abts.paper = blue;
                    break;
                case 16:
                    if (abts.bright == true) abts.paper = Color.RED.brighter();
                    else abts.paper = red;
                    break;
                case 24:
                    if (abts.bright == true) abts.paper = Color.MAGENTA.brighter();
                    else abts.paper = magenta;
                    break;
                case 32:
                    if (abts.bright == true) abts.paper = Color.GREEN.brighter();
                    else abts.paper = green;
                    break;
                case 40:
                    if (abts.bright == true) abts.paper = Color.CYAN.brighter();
                    else abts.paper = cyan;
                    break;
                case 48:
                    if (abts.bright == true) abts.paper = Color.YELLOW.brighter();
                    else abts.paper = yellow;
                    break;
                case 56:
                    if (abts.bright == true) abts.paper = Color.WHITE.brighter();
                    else abts.paper = white;
                    break;
            }
            return abts;
        }
  
  /*
 *  Object representing attribute values (colors) - ink, paper, bright and flash
 */ 
  private class AttribsBunch
  {
    public Color ink;
    public Color paper;
    public boolean bright;
    public boolean flash;
  }
  
  /*
 *  Returns an AtbsAdrAndCoords object with  x, y coords according to the 
 *  given VRAM address and also the address for attributes 
 */ 
  private AtbsAdrAndCoords VRAMComputeXY(int addr) 
  {
      int x, y;
      
      AtbsAdrAndCoords addressObj = new AtbsAdrAndCoords();
      
      addr = (addr - 16384);        //make the calculation more readable for humans...
      x = (addr % 32) * 8;
      int atribsX = addr % 32;
      int atribsY;
      int posY;
      int addLine;

      if (addr < 2048)
      {
          addLine = addr / 256; //o kolik se ma posunout na ose y od prvniho radku kazdeho 8mi radkoveho bloku
          addr = (addr - (256 * addLine));//uprav, pracovat budeme jen s prvnim radkem kazdeho 8mi radkoveho bloku, ten pak posuneme na ose y o vypocitany pocet radku
          posY = (addr / 32);
          y = posY * 8 + addLine;
          atribsY = posY;
      }
      else if (addr < 4096)
      {
          addr = (addr - 2048);
          addLine = addr / 256;
          addr = (addr - (256 * addLine));
          posY = (addr / 32);
          y = (posY * 8) + 64 + addLine;
          atribsY = (byte)(posY + 8);
       }
       else
       {
          addr = (addr - 4096);
          addLine = addr / 256;
          addr = (addr - (256 * addLine));
          posY = (addr / 32);
          y = (posY * 8) + 128 + addLine;
          atribsY = (posY + 16);
       }

        addressObj.x = x;
        addressObj.y = y;
        addressObj.AttribsAdr = (atribsY * 32 + atribsX + 22528);
        
        return addressObj;
    }
  
/**
 * Object representing x, y coords and attribute address
 */ 
  private class AtbsAdrAndCoords
  {
        public int x = 0;
        public int y= 0;
        public int AttribsAdr = 0;
    }

  /**
   * Refreshes VRAM, called every interrupt tick.
   */
    public void RefreshVRAM()
    {
        DrawVRAM();
    }
  
 /*
 * Launches an independent thread to refresh the screen 1/50 sec.
 */ 
  private void LaunchScreenRefresh()
  {
        ScreenRefresh refresh = new ScreenRefresh();
        refresh.launch();
        
  }
 
 /**
 * This subclas provides regular 1/50 sec screen refreshment
  * Refreshes VRAM on an independent thread. 
 */ 
  private class ScreenRefresh extends Thread
  {
      public ScreenRefresh()
        {
            setDaemon(true);
        }
        
        
        public void launch()
        {
            Thread thr = new ScreenRefresh();
            thr.start();
        }
        
        @Override public void run()
        {
            while (true)
            {
                Globals.paintingInProgress = true;
                flashPeriod++;
                if (flashPeriod == Globals.FlashFrequency)  //flash every 1/2 sec
                { 
                    flashPeriod = 0; 
                    VRAMFlash(); 
                    IsFlash = !IsFlash; 
                }
                DrawVRAM();
                Globals.paintingInProgress = false;
                
                try{Thread.sleep(Globals.ScreenRefreshFrequency);}
                catch(Exception e){}
            }
           
        }
     
  }
    
}
