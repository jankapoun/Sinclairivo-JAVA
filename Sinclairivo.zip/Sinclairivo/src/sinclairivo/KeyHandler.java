/*
 * This class handles the key strokes.
 * 
 */

package sinclairivo;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;

/**
 * This class handles the key strokes.
 * @author Jan Kapoun, Mgr.
 */
public class KeyHandler extends KeyAdapter
{
    private Keyboard kbd;
    
    /** Creates a new instance of KeyHandler
     * Receives the keyEvent.
    **/ 
    public KeyHandler(Keyboard kbd) 
    {
        this.kbd = kbd;
    }

    /**
     * Receives pressed key codes.
     */ 
    @Override public void keyPressed(KeyEvent e)
    {
        kbd.KeyDown(e.getKeyText(e.getKeyCode()));
    }
    
    /**
     * Receives released key codes.
     */ 
    @Override public void keyReleased(KeyEvent e)
    {
        kbd.KeyUp(e.getKeyText(e.getKeyCode()));
    }
    
}
