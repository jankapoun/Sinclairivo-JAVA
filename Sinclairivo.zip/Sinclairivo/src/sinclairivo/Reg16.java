/**
 * This class emulates the 16bit ZXS registers.
 */

package sinclairivo;

/**
 * Emulates the 16bit ZXS registers.
 * @author Jan Kapoun, Mgr.
 */
public class Reg16 
{
    private Reg8 low = new Reg8(0);  //lower register
    private Reg8 high = new Reg8(0); //higher register
    private USHORT value = new USHORT(0);
    
/**
 * Constructs 16bit register using 2 8bit registers.
 * Combining e.g. register H and reg L, the HL register
 * will be built. When changing either H or L, the HL
 * register will be changed accordingly.
 * 
 * USHORT is here to ensure data flow between high and low registers.
 * When the low register reaches 256, the low register is set to zero
 * and the high register must be increased by 1. This happens in the 
 * USHORT class.
 */
    public Reg16(Reg8 high, Reg8 low)
    {
        this.high = high;
        this.low = low;
        value.Set(this.Get());
    }
    
/**
 * Constructs 16bit register and sets it to the initial value.
 */
    public Reg16(int x)
    {
        value.Set(x);
        Set(value.Get());
    }
    
    public Reg16(int x, String name)
    {
        value.Set(x);
        Set(value.Get());
        value.SetName(name);
    }
    
/**
 * Sets the register to a certain value.
 */
    public void Set(int x)
    {
        value.Set(x);
        high.Set(value.Get() / 256);
        low.Set(value.Get() % 256);
    }
    
    
/**
 * Gets the value from the register.
 */
    public int Get()
    {
        return ((high.Get() * 256) + low.Get());
       
    }
    
/**
 * Sets the register to zero.
 */
    public void Res()
    {
        value.Set(0);
        high.Set(0);
        low.Set(0);
    }
    
/**
 * Adds the specified value to the register.
 */
    public int Plus(int x)
    {
        this.Synchronize();
        value.Plus(x);
        Set(value.Get());
        return value.Get();
    }
    
    public short Plus(short x)
    {
        this.Synchronize();
        value.Plus(x);
        Set(value.Get());
        return (short)value.Get();
    }
/**
 * Substracts the specified value from the register.
 */
    public int Minus(int x)
    {
        this.Synchronize();
        value.Minus(x);
        Set(value.Get());
        return value.Get();
    }

    public short Minus(short x)
    {
        this.Synchronize();
        value.Minus(x);
        Set(value.Get());
        return (short)value.Get();
    }

    
/**
 * Increases the register by 1.
 */
    public void Inc()
    {
        this.Synchronize();
        value.Inc();
        Set(value.Get());
    }
 
/**
 * Decreases the register by 1.
 */
    public void Dec()
    {
        this.Synchronize();
        value.Dec();
        Set(value.Get());
    }
   
/**
 * Synchronises the "high", "low" and "value" data
 */
    private void Synchronize()
    {
        Set(Get());
    }
}
