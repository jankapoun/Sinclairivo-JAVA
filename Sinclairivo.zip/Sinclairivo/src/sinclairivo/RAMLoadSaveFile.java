/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sinclairivo;
import java.io.*;
import java.nio.*;
import javax.swing.*;


/**
 * This class loads or saves a file into the ZX RAM.
 * @author Jan Kapoun, Mgr.
 */
public class RAMLoadSaveFile 
{
    
    public static void Load(String filename, RAM ram, int address)
    {
        try
        {
           FileInputStream iStream = new FileInputStream(filename);
            
            int b;
            try
            {
                while (true)
                {
                    b = iStream.read();
                    if (b == -1)
                    {
                        iStream.close();
                        return;
                    }
                    //ram.WriteRAM(address, b);
                    ram.WriteROM_NoCheck(address, b);
                    address++;
                }
            }
            catch (Exception e)
            {
                System.err.println("Load operation failed, file: " + filename);
            }
        
        }
        catch (Exception e)
        {
            System.err.println("File not found: " + filename);
        }
    
    }
    
/**
  * SNA snapshot format
  */   
//   Offset   Size   Description
//   ------------------------------------------------------------------------
//   0        1      byte   I
//   1        8      word   HL',DE',BC',AF'
//   9        10     word   HL,DE,BC,IY,IX
//   19       1      byte   Interrupt (bit 2 contains IFF2, 1=EI/0=DI)
//   20       1      byte   R
//   21       4      words  AF,SP
//   25       1      byte   IntMode (0=IM0/1=IM1/2=IM2)
//   26       1      byte   BorderColor (0..7, not used by Spectrum 1.7)
//   27       49152  bytes  RAM dump 16384..65535
//   ------------------------------------------------------------------------
//   Total: 49179 bytes
//    
    
   public static void LoadSnapshot(String filename, ZXMachine zxmachine)
   {
       Globals.snapshotLoading = true;
       while (Globals.CPUparserInProgress == true)
            {
                /**
                 * Waits for the parser to finish
                 * so new program can be loaded. 
                 */
                try{ Thread.sleep(10);} catch (Exception ex){} 
                
            }
                
      try
        {
           FileInputStream iStream = new FileInputStream(filename);
            
            try
            {
                    zxmachine.regs.regI.Set(iStream.read());
                    zxmachine.regs.regL_.Set(iStream.read());
                    zxmachine.regs.regH_.Set(iStream.read());
                    zxmachine.regs.regE_.Set(iStream.read());
                    zxmachine.regs.regD_.Set(iStream.read());
                    zxmachine.regs.regC_.Set(iStream.read());
                    zxmachine.regs.regB_.Set(iStream.read());
                    
                    zxmachine.regs.regF_.Set(iStream.read());
                    zxmachine.regs.regA_.Set(iStream.read());
                    
                    zxmachine.regs.regL.Set(iStream.read());
                    zxmachine.regs.regH.Set(iStream.read());
                    zxmachine.regs.regE.Set(iStream.read());
                    zxmachine.regs.regD.Set(iStream.read());
                    zxmachine.regs.regC.Set(iStream.read());
                    zxmachine.regs.regB.Set(iStream.read());
                    zxmachine.regs.regLY.Set(iStream.read());
                    zxmachine.regs.regHY.Set(iStream.read());
                    
                    zxmachine.regs.regLX.Set(iStream.read());
                    zxmachine.regs.regHX.Set(iStream.read());
                    
                    if((iStream.read() & 1) == 1){zxmachine.regs.regIFF = false;} //iff
                    else {zxmachine.regs.regIFF = true;}
                    zxmachine.regs.regR.Set(iStream.read());
                    zxmachine.regs.regF.Set(iStream.read());
                    zxmachine.regs.regA.Set(iStream.read());
                    
                    zxmachine.regs.regSP.Set(iStream.read() + (256 * iStream.read()));
                    zxmachine.regs.im.Set(iStream.read());
                    zxmachine.ports.border = iStream.read();//border color
                    
                    for (int i = 16384; i < 65536; i++)
                    {
                        zxmachine.ram.WriteRAM(i, iStream.read());
                    }
                    
                    iStream.close();
                 
                
            }
            catch (Exception e)
            {
                System.err.println("Snapshot loading operation failed, file: " + filename);
            }
        
        }
        catch (Exception e)
        {
            System.err.println("Snapshot file not found: " + filename);
        }
       
        Globals.snapshotSNARequest = true;
        Globals.snapshotLoading = false;

   
   }
   
   public static void SaveSnapshot(String filename, ZXMachine zxmachine)
   {
       
       Globals.snapshotLoading = true;
       while (Globals.CPUparserInProgress == true)
            {
                /**
                 * Waits for the parser to finish
                 * so new program can be loaded. 
                 */
                try{ Thread.sleep(10);} catch (Exception ex){} 
                
            }
       
        try
        {
           FileOutputStream outStream = new FileOutputStream(filename);
            
            try
            {
                outStream.write(zxmachine.regs.regI.Get());
                outStream.write(zxmachine.regs.regL_.Get());
                outStream.write(zxmachine.regs.regH_.Get());
                outStream.write(zxmachine.regs.regE_.Get());
                outStream.write(zxmachine.regs.regD_.Get());
                outStream.write(zxmachine.regs.regC_.Get());
                outStream.write(zxmachine.regs.regB_.Get());
                outStream.write(zxmachine.regs.regF_.Get());
                outStream.write(zxmachine.regs.regA_.Get());
                outStream.write(zxmachine.regs.regL.Get());
                outStream.write(zxmachine.regs.regH.Get());
                outStream.write(zxmachine.regs.regE.Get());
                outStream.write(zxmachine.regs.regD.Get());
                outStream.write(zxmachine.regs.regC.Get());
                outStream.write(zxmachine.regs.regB.Get());

                outStream.write(zxmachine.regs.regLY.Get());
                outStream.write(zxmachine.regs.regHY.Get());
                outStream.write(zxmachine.regs.regLX.Get());
                outStream.write(zxmachine.regs.regHX.Get());
                
                if (zxmachine.regs.regIFF == false){ outStream.write(0);}
                else {outStream.write(1);}
                
               outStream.write(zxmachine.regs.regR.Get());
               outStream.write(zxmachine.regs.regF.Get());
               outStream.write(zxmachine.regs.regA.Get());
               zxmachine.r.PUSH(zxmachine.regs.regPC);
               outStream.write(zxmachine.regs.regSP.Get() % 256);
               outStream.write(zxmachine.regs.regSP.Get() / 256);
               outStream.write(zxmachine.regs.im.Get());
               outStream.write(zxmachine.ports.border); //border color 
               

                for (int i = 16384; i < (65536); i++)
                {
                    outStream.write(zxmachine.ram.ReadRAM(i));
                }
                
                outStream.close();
            }
            catch (Exception e)
            {
                System.err.println("Save operation failed, file: " + filename);
            }
        
        }
        catch (Exception e)
        {
            System.err.println("File not found: " + filename);
        }
       
       Globals.snapshotLoading = false;
   
   }
   
   public static void Save(String filename, RAM ram, int start, int length)
    {
        try
        {
           FileOutputStream outStream = new FileOutputStream(filename);
            
            try
            {
                for (int i = start; i < (start + length); i++)
                {
                    outStream.write(ram.ReadRAM(i));
                }
                
                outStream.close();
            }
            catch (Exception e)
            {
                System.err.println("Save operation failed, file: " + filename);
            }
        
        }
        catch (Exception e)
        {
            System.err.println("File not found: " + filename);
        }
         
        
        
    }

}
