/*
 * This class contains all the ZXS CPU flags
 * 
 */

package sinclairivo;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Jan Kapoun, Mgr.
 */
public class Flags 
{
    private Reg8 regF = new Reg8(0);
    
 /*
 * Constructor, Registry class must be passed as argument
 */ 
    public Flags(Registers r)
    {
        this.regF = r.regF;
        if (Globals.ShowFlagsDebug.equals("yes")) { this.Debug();}
        else if (!Globals.ShowFlagsDebug.equals("no")){ System.err.println("ShowFlagsDebug: bad argument!");}
    }

/*
 * Carry flag, 0. bit
 */ 
    public boolean GetCarry() //0.bit
    {
        if ((regF.Get() & 1) == 0) return false;
        else return true;
    }
    
    public int GetCarryAsZeroOrOne()
    {
        return (regF.Get() & 1);
    }
    
    public void SetCarry(boolean b)
    {
        if (b){ regF.Set(regF.Get() | 1);} //set 0.bit
        else { regF.Set(regF.Get() & 254);} //reset 0. bit; }
    }
    
 /*
 * Complement carry flag
 */  
    public void CCFCarry()
    {
        if ((regF.Get() & 1) == 0) { SetCarry(true);}
        else
        {    
            regF.Set(regF.Get() & 254); //reset 0. bit;
        }
    }

 /*
 * N_Substraction flag, 1. bit
 */ 
    public boolean GetN_Substraction() //1.bit
    {
        if ((regF.Get() & 2) == 0) return false;
        else return true;
    }

    public void SetN_Substraction(boolean b)
    {
        if (b){ regF.Set(regF.Get() | 2);} //set 1.bit
        else { regF.Set(regF.Get() & 253);} //reset 1. bit; }
    }

        
 /*
 * PV flag, 2. bit
 */ 
    public boolean GetPV() //2.bit
    {
        if ((regF.Get() & 4) == 0) return false;
        else return true;
    }

    public void SetPV(boolean b)
    {
        if (b){ regF.Set(regF.Get() | 4);} //set 2.bit
        else { regF.Set(regF.Get() & 251);} //reset 2. bit; }
    }

 /*
 * 3 bit flag, 3. bit
 */ 
    public boolean GetFlagBit3() //3.bit
    {
        if ((regF.Get() & 8) == 0) return false;
        else return true;
    }

    public void SetFlagBit3(boolean b)
    {
        if (b){ regF.Set(regF.Get() | 8);} //set 3.bit
        else { regF.Set(regF.Get() & 247);} //reset 3. bit; }
    }

 /*
 * Half carry flag, 4. bit
 */ 
   public boolean GetHalfCarry() //4.bit
    {
        if ((regF.Get() & 16) == 0) return false;
        else return true;
    }

    public void SetHalfCarry(boolean b)
    {
        if (b){ regF.Set(regF.Get() | 16);} //set 4.bit
        else { regF.Set(regF.Get() & 239);} //reset 4. bit; }
    }

 /*
 * Flag bit 5 flag, 5. bit
 */ 
   public boolean GetFlagBit5() //5.bit
    {
        if ((regF.Get() & 32) == 0) return false;
        else return true;
    }

    public void SetFlagBit5(boolean b)
    {
        if (b){ regF.Set(regF.Get() | 32);} //set 5.bit
        else { regF.Set(regF.Get() & 223);} //reset 5. bit; }
    }
    
        
 /*
 * Zero flag, 6. bit
 */ 
    public boolean GetZero() //6.bit
    {
        if ((regF.Get() & 64) == 0) return false;
        else return true;
    }

    public void SetZero(boolean b)
    {
        if (b){ regF.Set(regF.Get() | 64);} //set 6.bit
        else { regF.Set(regF.Get() & 191);} //reset 6. bit; }
    }

 /*
 * Sign flag, 7. bit
 */ 
    public boolean GetSign() //7.bit
    {
        if ((regF.Get() & 128) == 0) return false;
        else return true;
    }

    public void SetSign(boolean b)
    {
        if (b){ regF.Set(regF.Get() | 128);} //set 7.bit
        else { regF.Set(regF.Get() & 127);} //reset 7. bit; }
    }

    /**
 * The Flags class debug system, shows registry values at regular intervals
 */      
    
    static JFrame theWindow = new JFrame("ZX Flags view");
    static Container wndContent = theWindow.getContentPane();
    static JTextArea TxtFlagsView = new JTextArea(); 
    

    public void Debug()
    {
        TxtFlagsView.setBounds(0, 0, 350, 300);
        TxtFlagsView.setFont(new Font("Verdana",20,10));
        wndContent.setLayout(new FlowLayout(FlowLayout.CENTER));
        wndContent.add(TxtFlagsView);
        theWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        theWindow.setBounds(600,300,350,120);
        theWindow.setVisible(true);

        DbgFlags dbg = new DbgFlags();
        dbg.launch();
    }
    
    public class DbgFlags extends Thread
    {
        public DbgFlags()
        {
            setDaemon(true);
        }
        
        public void launch()
        {
            Thread thr = new DbgFlags();
            thr.start();
        }
        
        
        public void run()
        {
            while(true)
            {
            TxtFlagsView.setText("Carry \tN_Substraction \tPV \t3.Bit");
            TxtFlagsView.append("\n" + GetCarry() + "\t" + GetN_Substraction() + "\t" +
                    GetPV() + "\t" + GetFlagBit3() );
            TxtFlagsView.append("\n-------------------------------------------------------------\n");            
            TxtFlagsView.append("HalfCarry \t5.Bit \tZero \tSign");
            TxtFlagsView.append("\n" + GetHalfCarry() + "\t" + GetFlagBit5() + "\t" +
                    GetZero() + "\t" + GetSign() );
                   
                    
            try{ Thread.sleep(700); }
            catch (Exception e){}
            }
        }
            
     }
 
}
