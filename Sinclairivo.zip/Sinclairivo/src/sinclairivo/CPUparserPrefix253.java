/*
 * Parses instructions following the 253 prefix code.
 * Index IY instructions
 */

package sinclairivo;

/**
 * Parses instructions following the 253 prefix code.
 * Index IY instructions
 * @author Jan Kapoun, Mgr.
 */
public class CPUparserPrefix253 
{
    private CPUroutines cpu;
    private Registers regs;
    private CPUparserPrefix253_203 prefix253_203;
    private int code;

    
    public CPUparserPrefix253(CPUroutines cpu, Registers regs)
    {
        this.cpu = cpu;
        this.regs = regs;
        prefix253_203 = new CPUparserPrefix253_203(cpu, regs);
    }
    
    public void Parse()
    {
        cpu.Refresh_R(); //obnov R registr
        code = cpu.Fetch();

        switch (code)
        {
        
            case 104:/*LD LY,B */
                {
                    cpu.LD(regs.regLY, regs.regB);
                }
                break;
            
            case 105:/*LD LY,C */
                {
                    cpu.LD(regs.regLY, regs.regC);
                }
                break;
                
            case 106:/*LD LY,D */
                {
                    cpu.LD(regs.regLY, regs.regD);
                }
                break;
                
            case 107:/*LD LY,E */
                {
                    cpu.LD(regs.regLY, regs.regE);
                }
                break;
                
            case 108:/*LD LY,HY */
                {
                    cpu.LD(regs.regLY, regs.regHY);
                }
                break;
            
            case 109:/*LD LY,LY */
                {
                    cpu.LD(regs.regLY, regs.regLY);
                }
                break;
                
            
            case 111:/*LD LY,A */
                {
                    cpu.LD(regs.regLY, regs.regA);
                }
                break;
          
            
            case 96:/*LD HY,B */
                {
                    cpu.LD(regs.regHY, regs.regB);
                }
                break;
            
            case 97:/*LD HY,C */
                {
                    cpu.LD(regs.regHY, regs.regC);
                }
                break;
                
            case 98:/*LD HY,D */
                {
                    cpu.LD(regs.regHY, regs.regD);
                }
                break;
                
            case 99:/*LD HY,E */
                {
                    cpu.LD(regs.regHY, regs.regE);
                }
                break;
                
            case 100:/*LD HY,HY */
                {
                    cpu.LD(regs.regHY, regs.regHY);
                }
                break;
            
            case 101:/*LD HY,LY */
                {
                    cpu.LD(regs.regHY, regs.regLY);
                }
                break;
            
            case 103:/*LD HY,A */
                {
                    cpu.LD(regs.regHY, regs.regA);
                }
                break;  
                
            case 38:/*LD HY,N*/
                {
                    cpu.LD_REG8_NN(regs.regHY);
                }
                break;
            
            case 46:/*LD LY,N*/
                {
                    cpu.LD_REG8_NN(regs.regLY);
                }
                break;  
                
            case 36:/*INC HY*/
                {
                    cpu.INC(regs.regHY);
                }
                break;
            
            case 37:/*DEC HY*/
                {
                    cpu.DEC(regs.regHY);
                }
                break;
            
            case 44:/*INC LY*/
                {
                    cpu.INC(regs.regLY);
                }
                break;
            
            case 45:/*DEC LY*/
                {
                    cpu.DEC(regs.regLY);
                }
                break;  
                
            case 69:/*LD B,LY*/
                {
                    cpu.LD(regs.regB, regs.regLY);
                }
                break;
            
            case 77:/*LD C,LY*/
                {
                    cpu.LD(regs.regC, regs.regLY);
                }
                break;
                
            case 85:/*LD D,LY*/
                {
                    cpu.LD(regs.regD, regs.regLY);
                }
                break;
                
             case 93:/*LD E,LY*/
                {
                    cpu.LD(regs.regE, regs.regLY);
                }
                break;
                
             case 125:/*LD A,LY*/
                {
                    cpu.LD(regs.regA, regs.regLY);
                }
                break;
                
             case 68:/*LD B,HY*/
                {
                    cpu.LD(regs.regB, regs.regHY);
                }
                break;
            
            case 76:/*LD C,HY*/
                {
                    cpu.LD(regs.regC, regs.regHY);
                }
                break;
                
            case 84:/*LD D,HY*/
                {
                    cpu.LD(regs.regD, regs.regHY);
                }
                break;
                
             case 92:/*LD E,HY*/
                {
                    cpu.LD(regs.regE, regs.regHY);
                }
                break;
                
             case 124:/*LD A,HY*/
                {
                    cpu.LD(regs.regA, regs.regHY);
                }
                break;   
                
             case 132:/*ADD A, HY*/
                {
                    cpu.ADD(regs.regA, regs.regHY);
                }
                break;
            
            case 133:/*ADD A, LY*/
                {
                    cpu.ADD(regs.regA, regs.regLY);
                }
                break;
                
            case 140:/*ADC A, HY*/
                {
                    cpu.ADC(regs.regA, regs.regHY);
                }
                break;    
                
            case 141:/*ADC A, LY*/
                {
                    cpu.ADC(regs.regA, regs.regLY);
                }
                break;  
                
            case 148:/*SUB A, HY*/
                {
                    cpu.SUB(regs.regA, regs.regHY);
                }
                break;    
                
            case 149:/*SUB A, LY*/
                {
                    cpu.SUB(regs.regA, regs.regLY);
                }
                break;      
                
            case 156:/*SBC A, HY*/
                {
                    cpu.SBC(regs.regA, regs.regHY);
                }
                break;    
                
            case 157:/*SBC A, LY*/
                {
                    cpu.SBC(regs.regA, regs.regLY);
                }
                break;          
               
            case 164:/*AND HY*/
                {
                    cpu.AND(regs.regA, regs.regHY);
                }
                break;
    
            case 165:/*AND LY*/
                {
                    cpu.AND(regs.regA, regs.regLY);
                }
                break;
            
            case 166:/*AND (IY + N)*/
                {
                    cpu.AND_RegA_FromWherePointsIX_IY_Shift(regs.regIY);
                }
                break;
                
            case 172:/*XOR HY*/
                {
                    cpu.XOR(regs.regA, regs.regHY);
                }
                break;
    
            case 173:/*XOR LY*/
                {
                    cpu.XOR(regs.regA, regs.regLY);
                }
                break;
                
                
            case 180:/*OR HY*/
                {
                    cpu.OR(regs.regA, regs.regHY);
                }
                break;
    
            case 181:/*OR LY*/
                {
                    cpu.OR(regs.regA, regs.regLY);
                }
                break;
            


            case 182:/*OR (IY + N)*/
                {
                    cpu.OR_RegA_FromWherePointsIX_IY_Shift(regs.regIY);
                }
                break;

            case 174:/*XOR (IY + N)*/
                {
                  cpu.XOR_RegA_FromWherePointsIX_IY_Shift(regs.regIY);
                  }
                break;

            case 188:/*CP HY*/
                {
                    cpu.CP(regs.regA, regs.regHY);
                }
                break;
    
            case 189:/*CP LY*/
                {
                    cpu.CP(regs.regA, regs.regLY);
                }
                break;
                
                
            case 190: /*CP (IY + N)*/
                {
                    cpu.CP_RegA_FromWherePointsIX_IY_Shift(regs.regIY);
                }
                break;

            case 52: /*INC (IY + N)*/
                {
                    cpu.INC_WherePointsIX_Shift(regs.regIY);
                }
                break;

            case 53: /*DEC (IY + N)*/
                {
                    cpu.DEC_WherePointsIX_Shift(regs.regIY);
                }
                break;

             case 134: /*ADD A,(IY + N)*/
                {
                    cpu.ADD_A_IX_IY_Plus_N(regs.regA, regs.regIY);
                }
                break;

            case 142: /*ADC A,(IY + N)*/
                {
                    cpu.ADC_A_IX_IY_Plus_N(regs.regA, regs.regIY);
                }
                 break;

             case 150: /*SUB(IY + N)*/
                 {
                     cpu.SUB_A_IX_IY_Plus_N(regs.regA, regs.regIY);
                 }
                 break;

             case 158: /*SBC A,(IY + N)*/
                 {
                     cpu.SBC_A_IX_IY_Plus_N(regs.regA, regs.regIY);
                 }
                 break;

            case 227:    /* EX (SP),IY */
                {
                    cpu.EX_ToWherePointsSP_IY();
                }
                break;

            case 249:  /* LD SP,IY*/
                {
                    cpu.LD(regs.regSP, regs.regIY, 10);
                }
                break;

            case 33: /*LD IY,NN*/
                {
                    cpu.LD_REG16_NN(regs.regIY, 14);
                }
                break;

            case 34:  /* LD (nn),IY*/
                {
                    cpu.LD_MEM_REG16(regs.regIY, 20);
                }
                break;

            case 42: /*LD IY,(NN)*/
                {
                    cpu.LD_REG16_FromWherePointsOp(regs.regIY, 20);
                }
                break;

            case 70: /*LD B,(IY + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regB, regs.regIY);
                }
                break;

             case 78: /*LD C,(IY + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regC, regs.regIY);
                }
                break;

            case 86: /*LD D,(IY + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regD, regs.regIY);
                }
                break;

            case 94: /*LD E,(IY + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regE, regs.regIY);
                }
                break;

            case 102: /*LD H,(IY + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regH, regs.regIY);
                }
                break;

            case 110: /*LD L,(IY + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regL, regs.regIY);
                }
                break;

            case 126: /*LD A,(IY + E)*/
                {
                    cpu.LD_REG8_From_IndexReg(regs.regA, regs.regIY);
                }
                break;

             case 112: /*LD (IY + E),B*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIY, regs.regB);
                }
                break;

             case 113: /*LD (IY + E),C*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIY, regs.regC);
                }
                break;

            case 114: /*LD (IY + E),D*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIY, regs.regD);
                }
                break;

            case 115: /*LD (IY + E),E*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIY, regs.regE);
                }
                break;

            case 116: /*LD (IY + E),H*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIY, regs.regH);
                }
                break;

            case 117: /*LD (IY + E),L*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIY, regs.regL);
                }
                break;

            case 119: /*LD (IY + E),A*/
                {
                    cpu.LD_ToWherePointsIndexReg_Reg8(regs.regIY, regs.regA);
                }
                break;

             case 54: /*LD (IY + E),N*/
                {
                    cpu.LD_ToWherePointsIndexReg_NN(regs.regIY);
                }
                break;

            case 35: /*INC IY*/
                {
                    cpu.INC_IndexReg(regs.regIY);
                }
                break;

            case 43: /*DEC IY*/
                {
                    cpu.DEC_IndexReg(regs.regIY);
                }
                break;

            case 9: /*ADD IY,BC*/
                {
                    cpu.ADD_IX_REG16(regs.regIY,regs.regBC);
                }
                break;

            case 25: /*ADD IY,DE*/
                {
                    cpu.ADD_IX_REG16(regs.regIY,regs.regDE);
                }
                break;

            case 41: /*ADD IY,IY*/
                {
                    cpu.ADD_IX_REG16(regs.regIY,regs.regIY);
                }
                break;

            case 57: /*ADD IY,SP*/
                {
                    cpu.ADD_IX_REG16(regs.regIY,regs.regSP);
                }
                break;

            case 229: /*PUSH IY*/
                {
                    cpu.PUSH_IndexReg(regs.regIY);
                }
                break;

            case 225: /*POP IY*/
                {
                    cpu.POP_IndexReg(regs.regIY);
                }
                break;

            case 233: /*JP (IY)*/
                {
                    cpu.JP_Index(regs.regIY);
                }
                break;

            case 203:
                {
                    prefix253_203.Parse();
                }
                break;

   
            default:
            {
              System.err.println("Prefix 253, instruction not supported, code: " + code + ", address: " + regs.regPC);
            }
        }
     }

}
