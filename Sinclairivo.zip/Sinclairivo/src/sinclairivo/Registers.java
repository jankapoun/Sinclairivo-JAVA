/**
 * Contains all the ZXS registry
 * @author Jan Kapoun, Mgr.
 */

package sinclairivo;
import javax.swing.*;
import java.awt.*;

public class Registers 
{
    public Registers()
    {
        if (Globals.ShowRegistryDebug.equals("yes")) { Debug();}
        else if (!Globals.ShowRegistryDebug.equals("no")){ System.err.println("ShowRegistryDebug: bad argument!");}
    }
            
 /**
 * Interrupt, refresh, flag, stack and program counter registry
 * 
 */
    protected boolean regIFF = false; //flip-flop registry, interrupt enabled/disabled
    protected boolean regIFF2 = regIFF;
    protected Reg8 im = new Reg8(0); //mod preruseni
    protected Reg8 regR = new Reg8(0); //refresh registry
    protected Reg8 regI = new Reg8 (0); //interrupt registry
    protected Reg8 regF = new Reg8 (0); //flag registry
    protected Reg8 regF_ = new Reg8 (0); //reserve flag registry
    protected Reg16 regSP = new Reg16(0,"Stack pointer"); //stack
    protected Reg16 regPC = new Reg16(0, "Program counter"); //program counter
    
    
 /**
 * Standard registry
 * 
 */
        protected Reg8 regA = new Reg8(0);
        protected Reg8 regB = new Reg8(0);;
        protected Reg8 regC = new Reg8(0);
        protected Reg8 regD = new Reg8(0);
        protected Reg8 regE = new Reg8(0);
        protected Reg8 regH = new Reg8(0);
        protected Reg8 regL = new Reg8(0);
        protected Reg8 regLX = new Reg8(0);
        protected Reg8 regHX = new Reg8(0);
        protected Reg8 regLY = new Reg8(0);
        protected Reg8 regHY = new Reg8(0);
        protected Reg16 regAF = new Reg16(regA, regF);
        protected Reg16 regBC = new Reg16(regB, regC);
        protected Reg16 regDE = new Reg16(regD, regE);
        protected Reg16 regHL = new Reg16(regH, regL);
        protected Reg16 regIX = new Reg16(regHX, regLX);
        protected Reg16 regIY = new Reg16(regHY, regLY);
        
 /**
 * Reserve registry
 */
        protected Reg8 regA_ = new Reg8(0);
        protected Reg8 regB_ = new Reg8(0);
        protected Reg8 regC_ = new Reg8(0);
        protected Reg8 regD_ = new Reg8(0);
        protected Reg8 regE_ = new Reg8(0);
        protected Reg8 regH_ = new Reg8(0);
        protected Reg8 regL_ = new Reg8(0);
        protected Reg16 regAF_ = new Reg16(regA_, regF_);
        protected Reg16 regBC_ = new Reg16(regB_, regC_);
        protected Reg16 regDE_ = new Reg16(regD_, regE_);
        protected Reg16 regHL_ = new Reg16(regH_, regL_);
        
/**
 * Registry related routines
 */
        
 /**
 * Refreshes the R register (increases)
 */
  public void Refresh_R()
  {
        regR.Inc();
  }
        
  
 /**
 * Sets the PC relatively, used in jumps
 */         
   public void SetPCRelativJump(short i)
    {
       regPC.Plus(i);
    }

 /**
 * The Registry class debug system, shows registry values at regular intervals
 */      
    
    static JFrame theWindow = new JFrame("ZX Registry view");
    static Container wndContent = theWindow.getContentPane();
    static JTextArea TxtRegView = new JTextArea(); 
    

    public void Debug()
    {
        TxtRegView.setBounds(0, 0, 350, 300);
        TxtRegView.setFont(new Font("Verdana",20,10));
        wndContent.setLayout(new FlowLayout(FlowLayout.CENTER));
        wndContent.add(TxtRegView);
        theWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        theWindow.setBounds(600,400,400,300);
        theWindow.setVisible(true);

        DbgRegistry dbg = new DbgRegistry();
        dbg.launch();
    }
    
    public class DbgRegistry extends Thread
    {
        public DbgRegistry()
        {
            setDaemon(true);
        }
        
        public void launch()
        {
            Thread thr = new DbgRegistry();
            thr.start();
        }
        
        public String DecToBin(Reg8 reg)
        {
            String s = "";
            if ((reg.Get() & 128) == 128){ s = s + "1";} else {s = s + "0";}
            if ((reg.Get() & 64) == 64){ s = s + "1";} else {s = s + "0";}
            if ((reg.Get() & 32) == 32){ s = s + "1";} else {s = s + "0";}
            if ((reg.Get() & 16) == 16){ s = s + "1";} else {s = s + "0";}
            if ((reg.Get() & 8) == 8){ s = s + "1";} else {s = s + "0";}
            if ((reg.Get() & 4) == 4){ s = s + "1";} else {s = s + "0";}
            if ((reg.Get() & 2) == 2){ s = s + "1";} else {s = s + "0";}
            if ((reg.Get() & 1) == 1){ s = s + "1";} else {s = s + "0";}
            return s;
        }
        
        public void run()
        {
            while(true)
            {
            TxtRegView.setText("A: " + regA.Get() + "\n" + "A: " + this.DecToBin(regA) + 
                    "\tF: " + regF.Get() + 
                    "\tB: " + regB.Get()
                    + "\tC: " + regC.Get() + "\nD: " + regD.Get() + 
                    "\tE: " + regE.Get() + "\tH: " + regH.Get() + 
                    "\tL: " + regL.Get());
            TxtRegView.append("\n-------------------------------------------------------------------\n");
            TxtRegView.append("A': " + regA_.Get() + "\tF': " + regF_.Get() + 
                    "\tB': " + regB_.Get()
                    + "\tC': " + regC_.Get() + "\nD': " + regD_.Get() + 
                    "\tE': " + regE_.Get() + "\tH': " + regH_.Get() + 
                    "\tL': " + regL_.Get());
            TxtRegView.append("\n-------------------------------------------------------------------\n");            
            TxtRegView.append("BC: " + regBC.Get() + "\tDE: " + regDE.Get()
                    + "\tHL: " + regHL.Get());
            TxtRegView.append("\n");
            TxtRegView.append("BC': " + regBC_.Get() + "\tDE': " + regDE_.Get()
                    + "\tHL': " + regHL_.Get());
            TxtRegView.append("\n-------------------------------------------------------------------\n");
            TxtRegView.append("IX: " + regIX.Get() + "\tIY: " + regIY.Get() +
                     "\nLX: " + regLX.Get() + "\tLY: " + regLY.Get() +
                     "\nHX: " + regHX.Get() + "\tHY: " + regHY.Get());
            TxtRegView.append("\n-------------------------------------------------------------------\n");
            TxtRegView.append("SP: " + regSP.Get() + "\tPC: " + regPC.Get() +
                     "\tR: " + regR.Get() + "\tI: " + regI.Get());
            TxtRegView.append("\n-------------------------------------------------------------------\n");
            TxtRegView.append("IFF: " + regIFF + ", mode: " + im.Get());

            
            try{ Thread.sleep(1000); }
            catch (Exception e){}
            }
        }
            
     }
    
}
    




