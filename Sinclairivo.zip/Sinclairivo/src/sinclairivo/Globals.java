/*
 * This class stores all the global variables and constants
 * 
 */

package sinclairivo;

/**
 *
 * @author Jan Kapoun, Mgr.
 */
public class Globals 
{
    public static String ShowRegistryDebug = "no"; // yes/no values, shows the Registry debug window
    public static String ShowFlagsDebug = "no"; // yes/no values, shows the Flags debug window
    public static String ShowKeyboardDebug ="no"; // yes/no values, shows the Keyboard debug window
    public static int ScreenRefreshFrequency = 1000/50;
    public static int FlashFrequency = 15; //Frequency of blinking attributes
    
    public static boolean reset = false; //resets the whole ZXS machine if set
    public static boolean pause = false; //pauses the ZXS machine
    public static boolean quality = true; //picture/screen rendering quality
    public static boolean pauseScreenRefresh = false; //pauses the screen refresh (menu can be pulled down)
    public static boolean snapshotSNARequest = false;// if true, does RET instruction and jumps into the snapped program.
    public static boolean snapshotLoading = false;
    public static boolean CPUparserInProgress = false;
    public static boolean paintingInProgress = false;
    public static boolean mapCursorAsKempston = false;
    
    /**
     * Zilog CPU speed, 
     * 20 approximates 3,5MHz - however, some time needs also the
     * emulator to execute, so -5 for approximation
     */
    
    public static int CPUspeed = 10;
    public static int sliderCPUspeedMin = 1;
    public static int sliderCPUspeedMax = 60;
    
    
}
