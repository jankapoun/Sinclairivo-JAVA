Sinclairivo
===========

Sinclairivo is an university project made as an exercise in my
JAVA course.

This program is a Sinclair ZX Spectrum emulator - an old 8bit computer
made in the United Kingdom and also in the Czech Republic as a clone
named Didaktik.

As part of the program you can find also a set of old Spectrum ROMs and
some gaming software to ilustrate the functioning of Sinclairivo.

Unfortunately, Sinclairivo doesn't support any sound output. Hopefully,
this will be added in the future. For the time being I have no idea
how to emulate sound. First, I got to study a couple of JAVA sound
libraries!

You can run any ZX Spectrum original machine code in this emulator.
Open the files with the .sna (memory snapshot), .bin (raw machine code)
or .rom (the ROM files) extensions. You can also save any code from
memory. However, both for loading and saving files, you neeed to know
the start adress and the code length respectively.
I've tried to run some original software in this emulator. Mostly it
functions. But there are some bugs in the instructions implementation, so
not everything runs...

About me:
I am currently studying at the university of South Bohemia, Czech Republic.
My major is the computer science. Basically, I am very interested in desktop
programming, using JAVA, C# and C++.
Contact: JanKapoun@seznam.cz

Enjoy Sinclairivo!

Mgr. Jan Kapoun